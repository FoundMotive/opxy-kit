# Kit 031 (OS 1.2.1)

Kit 031 is kit 030 plus Conductor, with one machine left out to fit memory.

## Credits
- Conductor by Max Mockett (mmockett), MIT. See machines/conductor/KIT-031-NOTICE.md.
- Track control and aux track SDK work ported from open-xy #345, PRs #198 and #234, and mm/control-notes (mmockett). etcetc000 credits are kept as in kit 030.

## Contents
All kit 030 machines plus Conductor, except Electric. The full set is about 104 KiB over the 2032 KiB module limit, so Electric (110.9 KiB) is left out. Fixed build: 2072672 of 2080768 bytes (about 7.9 KiB free).

## Tempo
Conductor reads the project tempo from the stock project. Notes follow the device song position; BPM sets only note length (120 BPM fallback). No BPM control is needed.

## Sound
Each lane plays whatever machine and sound is loaded on its target track (tracks 1 to 8) through stock live note on. Notes are not recorded.

## Before flashing
Not yet tested on hardware. Track control hooks and aux text edits are new to this OS port. Recovery: hold COM at power on.
