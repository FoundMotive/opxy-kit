# Kit 020: smoother Shaker, new Softegg

All machines, numbers, controls and kit 019 changes (loudness, soft ceiling, Guitar, Choir screen) as in kit 019 (built from kit-019 3d40954). Only the Shaker changed. Nothing here was flashed; install it yourself as with earlier kits.

## Shaker: why it was grainy and resonant, and the fixes
- Grain: the egg had few, large collisions (bead chance 2600 of 65536 per sample). The egg now has 5200 and the others are denser too, with each collision smaller. The egg stays at 5200 so the forward strokes still cut through (the onset test).
- High resonance: the shell resonators had high pole radii (egg 0.90, tube 0.98, seeds 0.94), so they rang as narrow peaks between about 7 and 13 kHz. Radii are now egg 0.81, tube 0.88, seeds 0.85 (cabasa stays 0.70), so the peaks are broad humps.
- Fizz: the white noise ran flat to Nyquist. It now passes a gentle two-tap filter (0.75, 0.25) and each material ends in a one-pole lowpass. This does the job of the filter you were adding by hand.
- Clipping: hard grains were driven into the soft ceiling. With a lower crest factor they now reach it less.
- Range: the bead sum could wrap at high Grain, and the old trim of 30000 overflowed the gain math. Trims now sit 4 times lower (the soft egg 8 times), with a clamped output shift, and the bead add saturates. The soft ceiling also clamps a rounding overshoot of up to 0.003 percent past -1 dBFS (found by the preview contract check).
- Material now has 5 positions: egg, tube, soft, cabasa, seeds. Saved presets keep their material: the stored words 2048, 12288, 20480 and 28672 still land on egg, tube, cabasa and seeds. The screen draws soft as a rounder egg.

## Softegg (new preset, material soft, control word 16384)
Fine sand in an egg moved gently, inspired by the soft shaker on Bon Iver's "There's a Rhythmn". It is synthesized, with no samples: 30000 of 65536 bead chance (many tiny grains), slow builds (520 forward, 1100 back) for a swish rather than a click, a broad low shell (3800 Hz, radius 0.55), a highpass tap (1, -0.9) to thin the lows like a real egg, and two lowpass stages for a dark, warm top. Its band levels relative to 1 to 4 kHz, from 500 Hz to 19 kHz, are -4.8, -2.6, -0.1, 0.7, 0.7, 0.2, -1.0, -3.5, -6.4, -9.0, -11.1 and -13.1 dB. For comparison, a measured egg shaker recording (Wikimedia Commons "Eggshaker_Solo.ogg" by Paddy, CC BY-SA 4.0, used only for analysis and not shipped) reads -9.8, -8.8, 0.2, 1.0, 6.6, 15.7, 16.7, 20.8, 20.8, 20.4, 18.3 and 8.3 dB. Softegg follows its low cut and is voiced much darker on top on purpose, which was the brief.

## Measured spectra above 6 kHz (C#4 16ths, 120 BPM, 8 s)
Peaks are frequency, dB over the 1 to 4 kHz band, then prominence over the surrounding octave.

| Preset | Kit 019 | Kit 020 | 8-16 kHz band 019 / 020 |
|---|---|---|---|
| default | 8010 +12.8 (3.1), 11122 +10.2, 12662 +10.1 (4.6) | 8107 +7.1 (1.9), 9647 +5.8, 11283 +5.3 (3.1) | +7.7 / +2.1 |
| tube | 7601 +21.9 (7.9), 10099 +17.3 (5.9), 13017 +14.4 (11.0) | 7429 +9.9 (3.4), 8958 +7.2 (2.9), 10573 +2.9 (2.3) | +7.7 / -1.3 |
| cabasa | 7860 +5.5 (1.9), 9378 +4.3 | 7289 +4.4 (1.9), 8915 +3.0 | -0.5 / -3.8 |
| seeds | 7677 +17.2 (5.9), 9636 +11.8 (4.1) | 7601 +8.4 (3.5), 9442 +4.6 (3.3) | +3.5 / -3.4 |
| loose | 13124 +13.1 (7.5), 7730 +12.9 (4.0) | 7289 +7.0 (2.3), 9087 +4.6 | +8.1 / +2.3 |
| softegg | none | 6912 +0.3 (1.0), 8419 -1.1 (1.2) | none / -6.2 |

## Levels (kit 019 method), RMS / peak dBFS
| Preset | Kit 019 | Kit 020 |
|---|---|---|
| cabasa | -28.3 / -2.5 | -28.3 / -1.8 |
| default | -26.5 / -1.0 | -26.8 / -1.1 |
| loose | -22.7 / -1.0 | -21.9 / -1.0 |
| seeds | -30.3 / -1.0 | -30.3 / -2.2 |
| softegg | none | -27.0 / -7.1 |
| tube | -23.1 / -1.0 | -23.1 / -1.0 |

## Measured (device simulator, limit 580K cycles per block)
Shaker one voice: worst 13,639, average 9,822 (kit 019: 9,102 and 5,980). Same hash on host and simulator. Voice state 132 bytes (was 120).

## Checks
`python sdk.py test --machine machines/shaker`, `python sdk.py check`, `tools/build_kit020.sh`, `tools/check_fixed_kit.py` against stock OS 1.2.0. Velocity sensitivity 22937, fixed full selection.

## Credits
SDK: Open-XY by etcetc000 (MIT). Shaker after Perry R. Cook's PhISEM idea. Guitar samples: Martin HD28 by Jeff Learman (CC0). Screen inspiration: Max Mockett's OP-XY machines (MIT). Reference recording for analysis only: "Eggshaker_Solo.ogg" by Paddy (CC BY-SA 4.0, Wikimedia Commons). Not affiliated with Teenage Engineering or Bon Iver.


# Earlier kits

# Kit 019: louder machines, a tighter Guitar, the original Choir screen

All machines, numbers and controls as in kit 018 (built from kit-018 f601551). Nothing here was flashed; install it yourself as with earlier kits.

## Choir screen
The Choir animation is back to the 2cc1fae drawing, exactly. The kit 018 Choir screen files are kept beside the tests as `machines/choir/tests/*-kit018*.txt` (renamed, not deleted). The other 018 animations are unchanged.

## Loudness
Every machine except Phase (already near full scale) is louder at base. Each machine ends in a shared 32-bit soft ceiling (`loud.hpp`): untouched below -4 dBFS, a quadratic knee above it, never past -1 dBFS (0.891 of full scale). This replaces the old hard clamp at half scale.
- Groove Kit about +7 dB, Guitar strums +8 to +10 dB and Notes +4 dB (its poly notes sum like the Choir), Shaker +13 dB, Upright Bass +10 dB, Piano +2 dB (its chord peaks set the limit).
- Choir: one held note +8 dB. Its voices sum on the device after the engine, so the make-up shrinks with the number of held notes (a four-note chord gains about 1 dB) to keep chords under full scale.
- Guitar has a per-mode gain, so quiet picking patterns come up closer to the strums.

Host level measurement, RMS / peak in dBFS: busy playing (chords or the pattern, 2 bars per change, 120 BPM), then a single held note where it applies.

| Machine | Preset | Kit 018 | Kit 019 | Single note 018 -> 019 |
|---|---|---|---|---|
| phase | bend | -12.4 / -0.4 | -12.4 / -0.4 | -18.7 / -9.1 -> -18.7 / -9.1 |
| phase | default | -10.2 / -0.3 | -10.2 / -0.3 | -16.2 / -9.5 -> -16.2 / -9.5 |
| phase | sine | -10.2 / -0.3 | -10.2 / -0.3 | -16.2 / -9.5 -> -16.2 / -9.5 |
| piano | default | -24.3 / -4.1 | -22.3 / -2.1 | -30.3 / -14.0 -> -28.3 / -12.0 |
| piano | felt | -23.9 / -3.1 | -21.9 / -1.1 | -29.9 / -13.6 -> -27.9 / -11.6 |
| piano | grand | -23.9 / -3.9 | -21.9 / -1.9 | -30.0 / -13.9 -> -28.0 / -11.9 |
| piano | honky | -28.2 / -6.4 | -26.2 / -4.4 | -34.7 / -15.7 -> -32.7 / -13.7 |
| choir | chant | -15.1 / -1.9 | -14.2 / -0.9 | -20.5 / -9.9 -> -12.6 / -2.2 |
| choir | chapel | -15.3 / -2.5 | -14.3 / -1.5 | -21.7 / -9.3 -> -13.8 / -1.8 |
| choir | default | -17.9 / -5.1 | -17.0 / -4.1 | -23.6 / -14.3 -> -15.7 / -6.3 |
| choir | ensemble | -16.9 / -4.7 | -16.0 / -3.7 | -22.7 / -10.1 -> -14.7 / -2.4 |
| choir | hum | -14.5 / -2.8 | -13.5 / -1.8 | -20.6 / -9.6 -> -12.6 / -2.0 |
| shaker | cabasa | -41.3 / -15.3 | -28.3 / -2.5 | |
| shaker | default | -39.5 / -11.3 | -26.5 / -1.0 | |
| shaker | loose | -35.6 / -9.9 | -22.7 / -1.0 | |
| shaker | seeds | -43.3 / -11.8 | -30.3 / -1.0 | |
| shaker | tube | -36.1 / -10.9 | -23.1 / -1.0 | |
| upright | default | -22.9 / -12.0 | -13.0 / -2.2 | |
| upright | neo-soul | -25.0 / -12.0 | -15.0 / -2.3 | |
| upright | slap | -21.3 / -11.6 | -11.4 / -1.9 | |
| upright | thumb | -24.5 / -12.0 | -14.6 / -2.3 | |
| upright | walking | -26.8 / -12.0 | -16.9 / -2.3 | |
| groovekit | alt-room | -24.2 / -4.0 | -17.4 / -1.0 | |
| groovekit | default | -24.6 / -5.9 | -17.7 / -1.0 | |
| groovekit | dusty-boom | -20.6 / -6.2 | -13.9 / -1.0 | |
| groovekit | funk-ghosts | -25.4 / -6.0 | -18.5 / -1.0 | |
| groovekit | kit-oneshot | -30.3 / -7.7 | -23.3 / -1.5 | |
| groovekit | latin-perc | -24.9 / -7.2 | -17.9 / -1.3 | |
| groovekit | no-hats | -24.7 / -6.0 | -17.8 / -1.0 | |
| groovekit | reggaeton | -23.2 / -4.5 | -16.5 / -1.0 | |
| groovekit | rnb-pocket | -26.0 / -7.0 | -19.1 / -1.2 | |
| groovekit | rock-oneshot | -29.7 / -6.3 | -22.8 / -1.0 | |
| groovekit | rock-tight | -24.3 / -4.0 | -17.7 / -1.0 | |
| guitar | ballad | -24.8 / -6.7 | -16.5 / -1.0 | |
| guitar | default | -22.8 / -6.1 | -14.8 / -1.0 | |
| guitar | dembow | -23.5 / -6.5 | -16.2 / -1.0 | |
| guitar | fingers | -24.9 / -8.4 | -16.9 / -1.2 | |
| guitar | island | -26.7 / -6.4 | -18.7 / -1.0 | |
| guitar | muted | -29.7 / -7.2 | -21.6 / -1.0 | |
| guitar | neosoul | -25.4 / -8.8 | -17.6 / -1.3 | |
| guitar | notes | -24.5 / -6.2 | -20.6 / -2.2 | -31.3 / -13.2 -> -27.3 / -9.2 |
| guitar | pima | -29.8 / -13.8 | -19.5 / -3.6 | |
| guitar | pop-16 | -24.4 / -7.2 | -16.3 / -1.2 | |
| guitar | slow-arp | -25.7 / -12.1 | -17.5 / -4.0 | |
| guitar | slowpick | -31.3 / -16.3 | -21.2 / -6.7 | |
| guitar | softcab | -24.1 / -8.7 | -15.8 / -1.4 | |
| guitar | thumb | -25.1 / -9.8 | -16.6 / -1.6 | |
| guitar | travis | -27.2 / -10.6 | -17.1 / -1.5 | |
| guitar | waltz | -26.9 / -12.4 | -18.7 / -4.4 | |

Busy playing reaches the -12 to -9 dBFS target only on the densest presets. Sparse picking patterns and one-shot kits have a high crest factor, so with peaks held under -1 dBFS their RMS stays lower.

## Guitar
- Release: strum presets now use amp release 30300, about 90 to 100 ms to -60 dB (it was over 3 s). Notes uses 26500, about 230 ms to -60 dB (it was 1.2 s). It still rings, but no longer drags.
- Transitions: a legato key or an overlapping key now just changes the chord, and the new chord sounds at the next step of the pattern. The pattern does not restart and no note is dropped. The old chord is damped gently until that step, so there is no silent gap and no double strike. A press right after a release, on the same voice or a new one, catches a step it missed by up to 30 ms, or plays one entry strum if the next step is far off. Once the guitar has fully released and stopped, a new key with the transport stopped starts the pattern from its top, not from a stale clock.
- Timing: the pattern follows the transport tick and corrects for coarse or jittery transport updates. A backward nudge across the bar line no longer re-locates and doubles a step. Tested at 60, 90, 120, 140, 160, 180, 200, 240 and 300 BPM with 8 presets, humanize on and off, 16 bars each, with an ideal, 4 tick, 6 tick and jittered (+/-2 tick) transport: no doubles, no skips, no drift. Kit 018 doubled and skipped steps with the coarse and jittered transports.

## Measured (device simulator, limit 580K cycles per block)
- Guitar, one voice: worst 92,713, average 59,913 (018: 111,629 and 61,150).
- Guitar, six Notes voices, room and tape full: worst 324,945 (018: 318,668).
- Groove Kit 40,571; Choir, eight keys 135,911; Piano 15,673; Upright 15,220; Shaker 9,102; Phase 11,273.

## Checks
`python sdk.py test` for every changed machine (the half-scale ceiling assertions now check the 0.891 ceiling), `python sdk.py check`, `tools/build_kit019.sh`, `tools/check_fixed_kit.py` against stock OS 1.2.0: all passed. Velocity sensitivity 22937, fixed full selection, Guitar samples 503,506 bytes, unchanged.

## Credits
SDK: Open-XY by etcetc000 (MIT). Guitar samples: Martin HD28 by Jeff Learman (CC0). Screen inspiration: Max Mockett's OP-XY machines (MIT). Not affiliated with Teenage Engineering.


# Kit 018: animated screens, a lighter and better-behaved Guitar

All machines, numbers and controls as in kit 016g (reserved or unused: 44/91, 45/92, 9/94, 41, 35). Scale Chord is unchanged. Nothing here was flashed; install it yourself as with earlier kits.

## Animated screens
New OP-XY-style moving screens for Guitar, Choir, Groove Kit, Phase, Piano and Upright Bass (the Shaker panel got a small SVG tidy-up). Each one reacts to note starts and to its own controls, and holds still with reduced motion:
- Guitar: a close look over the sound hole. The strings strum one by one at the Strum speed, the pick (or fingertip with Finger touch) follows, rings leave the sound hole. Notes mode plucks one string per key.
- Choir: a singing mouth in the Vowel's shape, rings into the hall shaped by Vibrato, Conson, Space, Vary and Human.
- Groove Kit: a round 16-step sequencer with Kick, Snare, Hats and Perc rings and a sweeping hand. Screens do not see the tempo, so the hand turns at a fixed 120 BPM (a bar in two seconds); the sound itself follows the transport.
- Phase: an X Y oscilloscope Lissajous figure bent by Bend, Drive and Color.
- Piano: felt hammers and eight strings ringing out over the Decay time.
- Upright Bass: plucked strings over the bridge with a sliding fingertip.

Vocal Tune, Cloud Pad, Tape, Tape Loop, Ping Pong and Ring Mod have no drawing hook in the SDK, so they keep their stock screens. The engine API carries no velocity, so the screens animate on note starts, not on how hard you play.

Inspiration: the animated screens of Max Mockett's OP-XY machines, https://mmockett.github.io/OP-XY/ (MIT). Nothing was copied; every screen is drawn new.

## Guitar
- Smaller samples, same sound: 665,686 bytes to 503,506 (162,180 bytes, 24 percent less). Each note keeps its 32 kHz attack and 24 kHz body bit for bit; once everything above 5.5 kHz has fallen below -60 dB the rest of the ring is stored at 12 kHz. A/B against 016g (Travis, ballad strum, Notes): every note identical up to its switch point, whole-render null about -50 dB (the codec's own floor), third-octave level change at most 0.25 to 2 dB at the 99th percentile and 0.005 dB median, far under the 1.6 dB the round robin varies itself.
- A new key no longer restarts the pattern. The pattern clock is shared by all Guitar voices: the transport when it runs, otherwise a free-running clock that keeps going while the guitar sounds (and for about 0.3 s after). A legato overlap, a key on a new voice, or a quick re-press after a short gap only changes the chord. Checked by a new host test that plays the device's note sequences (overlap and gap, same voice and a new voice, transport stopped and running): 016g restarted at tick 0 every time with the transport stopped, 018 carries on to within a tick.
- The register follows the keyboard octave, for strums and picking alike: below the default octave, low open or barre shapes with the root in the bass on the low E or A string and a slightly darker tone; the default octave keeps the 016g shapes; above it, brighter upper-position four-string shapes on D G B e (frets 4 to 12). All generated by `tools/kit018_chords.py` as playable fingerings of the same chord tones.

## Measured (device simulator, limit 580K cycles per block)
- Guitar, one voice: worst 111,629, average 61,150 (016g: 105,053 and 60,227).
- Guitar, six Notes voices, room and tape full: worst 318,668, average 255,360 (016g: 311,882).
- Choir, eight keys: worst 131,561.
- Host and simulator output hashes match.

## Checks
`python sdk.py test` for every changed machine, `tools/build_kit018.sh` (GNU link parity and independent verification), `tools/check_fixed_kit.py` against stock OS 1.2.0: all passed.

## Credits
SDK: Open-XY by etcetc000 (MIT). Guitar samples: Martin HD28 by Jeff Learman (CC0). Not affiliated with Teenage Engineering.



# Kit 017 (same build as kit 016g: guitar Notes mode)

Guitar machine only; all other machines, numbers and controls unchanged.

## Notes mode
- Set Mode to its new last value, `notes` (the Mode header reads "notes"). Each key then plays its own chromatic pitch as one plucked guitar note. Key and Pattern are ignored. Touch (finger or pick), Room, Tape and Strum's neighbours work as before; Touch also sets the tone.
- New preset `notes`: finger touch, poly play mode, a slightly longer amp release so the note rings on a little after key-up.
- Up to 6 notes at once (voiceCapacity 2 to 6). Notes below E2 fold up an octave, above E6 fold down.
- Each note picks a plausible string: the lowest comfortable fret, avoiding a string another held note is ringing. A new note on a string another note holds fades that note the 016f way (about 55 ms for the same note, 25 ms for a new fret, low-pass closing).
- Round robin: every strike differs a little in start point (stepped so consecutive strikes never match), onset brightness, up to about 2 cents of tuning, level (about 0.5 dB) and a soft pluck noise. A repeated note sometimes moves to the neighbouring string.
- Finger uses the fingerpicked tone of the travis patterns; pick uses a picked note.
- Velocity and key-up release come from the device's amp envelope (velocity sensitivity 22937, release 15000 in the preset); the engine API has no velocity or note-off.

## Changes to note
- Mode has 7 values now; every preset's Mode value was re-saved so it keeps its chord type. Projects saved with 016f or earlier may show the next Mode value along.
- A presets folder holds at most 16, so `cabin` moved to `machines/guitar/spare-presets/cabin.json` (renamed, not deleted; `softcab` is close).

## Measured
- Devsim, one voice (standard driver): worst 105,053 cycles per block, average 60,227.
- Devsim, six Notes voices at once, room and tape full, strikes and re-strikes (`tools/devsim/synth_notes.sh`): worst 311,882, average 250,519 (limit 580K).
- Caveat: a strum preset switched to poly by hand with six chords held could reach about 6 x 105K; all strum presets are mono.
- Repeated E4 strikes: no two consecutive strikes identical.
# Kit 016f: natural damping and grooved strums

Guitar machine only; all other machines, numbers and controls unchanged.

## Damping
- Damped strings fall away over roughly 40 to 120 ms instead of cutting off: hand lift about 120 ms, chuck damp about 70 ms, chord change or key release about 120 ms, muted plucks longer.
- A low-pass closes on every damping string, so the note darkens as it stops.
- A re-struck string hands over in about 55 ms (same note) or 25 ms (new fret), darkening as it fades.
- Muted chucks are softer and their hand noise decays more slowly.

## Strums (patterns 1 to 10)
- Each stroke has its own groove push: downbeats on the grid, last-eighth anticipations early, offbeat ups laid back, plus gentle 2-bar phrase breathing. Random drift is halved.
- Accent maps: ghosted ups, accented beats and backbeats, with a wider gain curve.
- Less random velocity (36 to 20) and spread variance.
- Finger strums: softer, darker onsets. Pick: a slightly softer onset.

## Measured (host render, human 0)
- pop16 stroke level spread (10th to 90th pct): 11.9 dB (016e) to 17.1 dB (016f).
- Muted chuck fall of 20 dB: 9 ms to 15 ms; spectral centroid unchanged (1244 vs 1238 Hz).
- Devsim: worst 105,020 cycles per block, average 68,228 (limit 580K).
# Kit 016e: soft, sweet fingerpicking

Kit 016e is built on 016d. Only Guitar changes. The controls, labels, machine numbers, tempo lock and chord-change behavior are unchanged.

## Changes

- roll and p-i-m-a are now eighth-note based, with occasional 16th ornaments. travis and slowpik keep their speed.
- Softer onsets on picked notes: each fades in over 8 to 15 ms (was 5 to 7) and starts about 4 ms past the pick click (was 2). The tone starts very dark and opens over about 45 ms (was 17), and the note is darker overall.
- Wider dynamics, written per note:
  - The thumb is steady and moderate.
  - The top-string melody is accented on chosen beats.
  - Inner notes are quiet or ghosted.
  - The squared velocity curve puts ghosts far below accents.
  - Picking velocities are lower overall.
- Rhythm: the groove maps described in machines/guitar/README.md, with phrase breathing, rolled pinches and less randomness.
- Strums get a light groove: the last eighth of a bar pushes, and offbeats lean back.
- The travis, pima and slowpick presets are darker, with a little more room and tape warmth.

## Numbers

- Blackfin devsim: worst 97,773 and average 65,727 cycles per block (016d: 101,706 and 65,920). The limit is 580K.
- 1.bin is 1168836 bytes and the LDR is 3534036 bytes.

Demos are in /workspace/private/kit016e-audio. Nothing was flashed or pushed.

# Kit 016d: grooving fingerpicking

Kit 016d is built on 016c. Only the Guitar picking patterns change. Sounds, controls, labels, machine numbers, tempo lock and chord-change behavior are unchanged.

## Changes

- All five picking patterns are rewritten as two-bar phrases, and bar 2 differs from bar 1.
- travis, roll and p-i-m-a run in 16ths, about twice as fast as 016c at 88 BPM. arp bal mixes eighths and sixteenths, and slowpik keeps slower, uneven phrasing.
- Travis: the thumb alternates the bass on the beats (with an extra 8th in bar 2), fingers fill and push into the beats, and pinches land on 1 (and on 3 in bar 2).
- Swing: the 2nd and 4th 16ths land late (about 56 percent, up to 58 with Human).
- Accents: those 16ths sit softer, under the existing accent hierarchy and phrase swells.
- Timing feel: the thumb is held to half the timing drift, while the fingers drift a quarter more, with extra jitter and level variation.
- Notes keep ringing and overlapping, and there are a few double plucks.

## Numbers

- Blackfin devsim: worst 101,706 and average 65,920 cycles per block (016c: 97,765 and 64,814). The limit is 580K.

Demos are in /workspace/private/kit016d-audio. Nothing was flashed or pushed.

# Kit 016c: Finger and Pick, fingerpicking

Kit 016c is built on 016b. Only Guitar changes. All machine numbers are kept, and the fixed full selection is the same.

## Control mapping

Page 2, knob 1 is now Touch, which replaces Tone. All 8 parameter slots were already used, and shift+turn and press are taken by fine steps and the page switch, so the cleanest place was to split the tone knob:

- 0 to 49 percent: Finger, dark to open.
- 50 to 100 percent: Pick, dark to open. Old Tone values map into this half, so 016b presets sound the same.
- The header reads "finger" or "pick" while you turn it.

Pattern gains five fingerpicking patterns after single: travis, arp bal, roll, p-i-m-a, slowpik. They are described in machines/guitar/README.md. No other controls changed, and all labels are 8 characters or fewer.

## Changes

- Finger touch: a per-string 5 to 7 ms fade-in, starting about 2 ms past the pick click, with a darker onset that opens over about 17 ms. The sound is warmer, with a slower and steadier sweep, smaller level differences between strings and no pick noise (only a faint flesh brush). Ups are soft nail brushes.
- Pick touch: the onset is slightly softened (a 0.5 ms fade-in and a darker first 6 ms).
- Fingerpicking: each note rings and overlaps, is tempo-locked, uses the flesh attack and is humanized, and the thumb is stronger.
- New presets: thumb, fingers, softcab, travis, pima, slowpick. Existing presets were remapped to the new Pattern and Touch ranges.

## Numbers

- Blackfin devsim: worst 97,765 and average 64,814 cycles per block (016b: 95,750 and 62,340). The limit is 580K.
- 1.bin is 1,167,408 bytes and the LDR is 3,532,608 bytes.
- Voice is 6,976 bytes.

Demos are in /workspace/private/kit016c-audio. Nothing was flashed or pushed.

# Kit 016b

Kit 016b is kit 016 with a Guitar that strums like a person. The string tone, controls, presets, machine numbers and every other machine are unchanged. Guitar is still engine 48, page 96.

## What changed in Guitar

Human scales all of it. The default (35 percent) already sounds played, and 0 is still machine tight.

- Microtiming: a smooth random walk pushes and pulls the timing for a few strokes at a time, with a little jitter on top. Beat 1 is tightest, offbeats loosest, and offbeat ups lay back slightly.
- Dynamics: accents on beat 1 and the backbeats, lighter offbeats and ups, a four-bar swell with a slow random drift, and per-stroke variation.
- Strum shape: each stroke has its own speed (quick to lazy), the hand speeds up through the strum, ups often hit only the top three strings, downs sometimes miss the top or bass string, and the level tapers across the strings.
- Details: ghosted and missed offbeat ups. Open strings on the last up of a bar as the hand moves to the next chord. A faint finger noise on chord changes and a little pick noise on downs. Round robin on every note (under a cent of pitch, start point, brightness). Harder strokes are brighter, ups thinner.
- Ringing: strings the pick skips keep ringing, and a re-struck string hands over smoothly instead of cutting.

## Numbers

- Blackfin devsim, cycles per 64-sample block: worst 95,750, average 62,340 (kit 016 in the same run: 83,890 and 58,082). The budget is 580,000.
- The host CPU estimate is about 36,300 (kit 016 was about 25,600). The SDK warns above 24,000, but the device simulator figure is the real one.
- Firmware module (reference/1.bin): 1,166,156 bytes (kit 016: 1,163,948). Full LDR: 3,531,356 (kit 016: 3,529,148).
- Voice memory: 6,776 bytes (kit 016: 6,672).
- SDK tests pass. Worst tuning is still within 3 cents, and tempo lock and chord-change phase still hold.

## What to check

Play the default preset at 88 BPM over C, G, Am, F. It should feel loose but in time, with louder downbeats. Try Human at 0 and at full to hear the range.

# OP-XY kit 016 (Kieran)

Kit 016 is kit 015b plus a new engine, **Guitar**, and a much smaller Groove Kit.

Machines (17): Macro Osc, Karplus, 2op FM, Phase, Piano, Shaker, Choir, Upright Bass, Groove Kit and Guitar engines, the Vocal Tune and Cloud sample engines, the Scale Chord player, and Ring Mod, Ping Pong, Tape character and Tape Loop send effects.
Built for stock OP-XY OS 1.2.0. Source: local branch kit-016 (open-xy SDK fork, MIT, etcetc000 and contributors). Not pushed, not flashed.
Fixed kit: the builder installs the full set of machines only.

## Machine numbers

Unchanged from kit 015b. New:

| Machine | Kind | Number | Page |
| --- | --- | --- | --- |
| Guitar (new) | engine | 48 | 96 |

Still reserved, never reused: 44/91 (Brushed Kit), 45/92 (Boom Bap), 9/94 (Groove player), 41 and 35.

## 1. Guitar (48/96)

A warm, close-mic acoustic guitar. Pick a Key and a Mode; every key plays the chord of its scale degree (black keys play borrowed chords), strummed in a pattern locked to the song tempo. Hold a key to play, release to stop. Full guide: machines/guitar/README.md.

Page 1: Key, Mode, Pattern, Human. Page 2 (press a knob): Tone, Room, Tape, Strum.

- Modes: major, minor, maj7, min7, maj add, min add (add9 and sus colours).
- Patterns: folk 8, ballad, island, neosoul, regton, waltz, pop 16, slow arp, muted, single.
- The screen header shows the key (for example "Am") and the mode or pattern you are turning.
- Lower octave of the keyboard: full six-string shape. One octave up: lighter top-four-string voicing.
- Presets (all 70 percent velocity sensitivity): default, ballad, island, neosoul, dembow, waltz, pop-16, slow-arp, muted, cabin.

Tuning: each string is a real recorded Martin HD28 note, retuned per note. Measured after the engine, every pitch MIDI 36 to 86 is within 0.9 cents; the SDK sound test (harmonic DFT) worst case is 1.1 cents. Tempo lock tested at 75, 88 and 120 BPM; a chord change keeps the pattern phase.

Levels at defaults, 88 BPM: -22 to -29 dBFS RMS, peaks at most 0.57 of full scale. Worst case at all extremes: 0.333 in the test harness (one voice).

## 2. Groove Kit is smaller

Groove Kit samples shrank from 405,760 to 171,972 bytes (hits trimmed to where they decay into the noise floor, rates matched to content). It sounds the same: before against after null tests across all styles leave a residual of -44.9 to -52.2 dB under the signal, band levels within 0.04 dB. Controls, patterns, presets and loudness unchanged.

## Sizes and cycles

| | kit 015b | kit 016 |
| --- | --- | --- |
| Firmware module (reference/1.bin) | 710,664 | 1,163,948 bytes |
| Full LDR | 3,075,864 | 3,529,148 bytes |

Guitar sample data: 15 notes, about 665 KB in the module. Saved by Groove Kit: about 234 KB.

Blackfin devsim, cycles per 64-sample block (budget 580,000):

| Machine | Worst | Average |
| --- | --- | --- |
| Guitar | 79,335 | 59,490 |
| Groove Kit (016) | 37,738 | 29,744 |
| Groove Kit (015b) | 36,201 | 28,672 |

## Checks run

- SDK tests for guitar and groovekit: pass (screen, sound, tuning, tempo lock).
- tools/build_kit016.sh: build complete, link parity with GNU ld (module 1,936,916 bytes).
- check_fixed_kit.py against stock OS 1.2.0: passed.

## Caveats

- Muted chucks are synthesized (damped strings plus a filtered noise burst); there were no CC0 muted recordings of this guitar.
- One velocity layer of samples; softer playing is quieter and a little darker, not a different recording.
- Ring portions are stored at 24 kHz (pick attack at 32 kHz), so the very top air is rolled off. Suits the warm sound.
- The raw recordings are 8 to 14 cents flat; this is corrected per note.
- The host-timed CPU estimate for Guitar is about 25,600 (the SDK warns above 24,000). The device simulator figure above is the real one and is far under budget. Guitar is mono, one voice.
- The browser preview memory was raised from 512 KB to 1 MB (tooling/preview.py) to fit the guitar samples. Preview only, not the device.
- The firmware is about 453 KB bigger than 015b.

## What to check

1. Guitar default preset at 88 BPM: hold C, then G, Am, F. Chords should change on the beat without the strum skipping.
2. Try Mode maj7 and maj add: the chords should sound open, not muddy.
3. Groove Kit should sound and feel exactly as in 015b.

## Credits

Open-XY SDK by etcetc000 and contributors, MIT.
Guitar samples: Jeff Learman, Martin HD28 samples, Discord SFZ GM Bank (github.com/kinwie/Discord-SFZ-GM-Bank, revision 05d5ed8b), CC0 1.0. License: machines/guitar/SAMPLES-LICENSE.txt.
Groove Kit samples: as credited in kit 015 (unchanged sources, re-encoded).

# Kit 015b

Kit 015b is kit 015 with two fixes.

## 1. Groove Kit is louder

Groove Kit now starts about 10 dB louder, level with the stock drum and sampler tracks and with Upright Bass, Piano and Choir.

- Loops at default settings (88 BPM): -24.2 to -25.8 dBFS RMS. Kit 015 measured -34.1 to -35.7.
- Peaks at defaults: -3.8 to -5.9 dBFS.
- A soft clipper holds every voice under 0.72 of full scale. The worst case (all 14 Style values, Grit, Room, Tone, Punch, Feel and Human all at full, at full velocity) peaks at -3.5 dBFS. Nothing clips.
- The velocity stage only turns hits down, so full velocity is the loudest case. Soft playing is quieter (about 70 percent sensitivity).
- Sound, patterns, controls and presets are otherwise unchanged.

## 2. Brushed Kit and Boom Bap Kit still showing

Cause: the old engines are not in the firmware. The kit 015 and 015b builds contain no Brushed Kit, Boom Bap or Groove player entry anywhere: not in the machine list, not in the device catalog (op1_factory.json) and not in the screens. What you see are leftover files on the OP-XY from the kit 013 install. The browser flasher only adds and replaces files and never deletes any, so these stayed on the device:

- content/presets/brushkit/ (ballad, brushes, default, dry, swing)
- content/presets/boombap/ (clean, default, lazy, no-hats, sp-dust)
- content/display/brushkit.svg and content/display/boombap.svg (old screen artwork, harmless)

The device lists the preset folders, but their engine is gone, so they do nothing. Flashing again cannot remove them, and the flasher does not remember anything that brings them back. The machine numbers it remembers are only numbers.

What to do (once, after flashing 015b):

1. Connect the OP-XY to the computer in its normal USB file mode (the same connection the flasher uses to send files).
2. Open the device in a file manager. On Windows use File Explorer. On a Mac use an MTP app such as OpenMTP or Android File Transfer.
3. Open content/presets. Copy the brushkit and boombap folders to your computer as a backup, then delete both folders from the OP-XY. If you saved your own sounds into them, they are in that backup.
4. Optional: delete content/display/brushkit.svg and content/display/boombap.svg the same way.
5. Leave every other folder alone, including content/presets/groovekit and content/op1_factory.json.
6. Restart the OP-XY.

Machine numbers do not change. Brushed Kit (44/91), Boom Bap Kit (45/92) and the Groove player (9/94) stay reserved in layout.json so no machine can ever take them. Reserved numbers register nothing on the device. The Groove player was a note player with no presets, so it leaves no files behind and does not show up. Projects that used Brushed Kit or Boom Bap already could not play them; every other machine keeps its number.

## What to check

1. Groove Kit, default preset, track volume at its default: hold a key at 88 BPM. It should be about as loud as a stock drum track.
2. Turn Grit, Room and Tone fully up and play hard. It should get dirtier but not clip.
3. After the cleanup above and a restart: Brushed Kit and Boom Bap no longer appear, Groove Kit and every other machine still do, and old projects open with their machines in place.

# OP-XY kit 015 (Kieran)

Kit 015 replaces the Groove player with a new engine, **Groove Kit**: a sampled acoustic drum kit that plays tempo-locked 2-bar loops, built the same way as Shaker. Hold a key and its loop plays in time with the song. Release the key and it stops.

Machines (16): Macro Osc, Karplus, 2op FM, Phase, Piano, Shaker, Choir, Upright Bass and Groove Kit engines, the Vocal Tune and Cloud sample engines, the Scale Chord player, and Ring Mod, Ping Pong, Tape character and Tape Loop send effects.
Built for stock OP-XY OS 1.2.0. Source: local branch kit-015 (open-xy SDK fork, MIT, etcetc000 and contributors). Not pushed.
Fixed kit: the builder installs the full set of machines only.

## Machine numbers

Unchanged from kit 014c, except as noted:

| Machine | Kind | Number | Page |
| --- | --- | --- | --- |
| Groove Kit (new) | engine | 47 | 95 |
| (Groove player, removed) | player | 9 reserved | 94 reserved |
| (Brushed Kit, removed) | engine | 44 reserved | 91 reserved |
| (Boom Bap Kit, removed) | engine | 45 reserved | 92 reserved |

All other machines keep their kit 014c numbers (table under Kit 014 below). The layout.json in this zip holds every number, including the reserved ones. Projects that used the Groove player lose that player; nothing else moves.

## Groove Kit (engine 47, page 95)

### How it plays

- Pattern mode: every key is its own 2-bar loop (768 ticks). Bar 2 ends in a fill. The loop follows the song tempo and the song position while you hold the key, so it lands in time even if you press late. Tuned for 75 to 120 BPM; it sits best at 85 to 90.
- Lower octave keys (C to B of an even octave): main grooves with a short fill on the last beat. Upper octave keys: busier variations (extra ghost notes, an open hat) with a longer fill over the last two beats. The top keys in each octave play a groove as bar 1 and a full fill bar as bar 2.
- Seven styles, each with a full 24-key set: Hip Hop, Alt, R&B, Rock, Reggaeton, Latin, Funk (168 loops, 5,907 hits).
- Ghost notes and accents come from the patterns. Human adds timing drift (up to 6 ms, 9 ms on ghosts) and small level changes. Each style also has its own per-part lag (laid-back snare in Hip Hop and R&B, pushed hats in Funk) and its own tuning of the kit.
- Note velocity: the engine runs with the stock velocity stage at about 70 percent sensitivity, so playing harder is louder.

### Controls (the 16 knob actions)

Page 1 (Knobs 1 to 4):

| Knob | Label | What it does |
| --- | --- | --- |
| 1 | Style | 14 values. hiphop, alt, rnb, rock, regton, latin, funk play loops. hh shot, altshot, rnbshot, rk shot, rg shot, la shot, fk shot are the same kits in one-shot mode (see below). |
| 2 | Parts | all, no hats, no kick, no perc, kick sn, no snr, hat perc, kick. Mutes parts of the loop (use it for breakdowns). |
| 3 | Feel | Swing amount on the off 16ths. Each style has its own base swing (Hip Hop and R&B swing most, Rock and Reggaeton are straight). |
| 4 | Human | Timing and level looseness. 0 is quantized. |

Page 2 (press the page button; Knobs 1 to 4):

| Knob | Label | What it does |
| --- | --- | --- |
| 1 | Tone | Below the middle: darker. Above: brighter top end. |
| 2 | Punch | Tighter, punchier hits with shorter tails. |
| 3 | Grit | Drive into a soft clipper. Dirtier, not louder. |
| 4 | Room | Small room ambience. |

The screen shows the Style and Parts names as headers, a text line with the mode and style (for example PATTERN HIP HOP or ONE SHOT ROCK), part lamps, and a black and white animation that moves with the loop.

Level: there is no Level knob in the engine (the 8-parameter limit). Use the track volume. Shift-turn gives fine steps as on stock engines.

### One-shot mode (a normal drum kit)

Set Style to one of the shot values (hh shot to fk shot). Patterns stop, and every key plays one drum hit, velocity sensitive. A closed hat or pedal hat chokes a ringing open hat, across voices. The kit keeps that style's tuning.

Key map (same in every octave pair; the even octave is the lower row):

| Key | Lower octave | Upper octave |
| --- | --- | --- |
| C | Kick | Soft kick |
| C# | Cross stick | Soft cross stick |
| D | Snare | Brush-style soft snare (a soft snare layer pitched down; there is no brush sample) |
| D# | Ghost snare | Feather ghost snare |
| E | Rimshot | Medium snare |
| F | Low tom | Lower tom |
| F# | Closed hat | Soft closed hat |
| G | High tom | Higher tom |
| G# | Pedal hat | Accent closed hat |
| A | Tambourine | Soft tambourine |
| A# | Open hat | Soft open hat |
| B | Shaker | Soft shaker |

The engine does not receive note velocity directly; the stock level stage applies it (about 70 percent). The soft keys use the real soft velocity layers, so tone changes as well as level.

### Presets

default, dusty-boom, alt-room, rnb-pocket, rock-tight, reggaeton, latin-perc, funk-ghosts, no-hats, kit-oneshot, rock-oneshot.

### Sound and measurements

- Real recorded drums: 25 hits from Virtuosity Drums (CC0), resampled to 32 kHz, 16-bit, 405,760 bytes baked into the engine. Kick in 2 velocity layers with round robin, snare in 5 layers, rimshot, 2 cross stick layers, closed hat in 3 layers with round robin, pedal hat, open hat, 2 toms, shaker and tambourine with round robin.
- Loudness matched to the stock-matched kit 013 Boom Bap at defaults: Groove Kit loops measure -34.1 to -35.7 dBFS RMS, Boom Bap -36.5. Peaks -11.8 to -15.3 dBFS. A soft clipper holds the worst case (Grit, Room and Tone full) at 0.45 of half scale. No clipping.
- Against kit 013 Boom Bap (88 BPM, both keys of each style): less low-end dominance (energy below 150 Hz 31 to 66 percent of the total, Boom Bap 80 percent), so snare and hats are heard instead of only the kick; spectral fullness 0.50 to 0.75 for the loops and 0.92 for the one-shot run (Boom Bap 0.79); natural transients (onset score 2.6 to 3.0, Boom Bap 3.3, whose synthetic clicks are sharper).
- CPU (Blackfin simulator, tools/devsim/synth.sh with SYNTH_TRANSPORT, host and device hashes match): worst 35,405 cycles per block (average 25,989); all controls full worst 35,701. Six voices worst case about 214,000 of the 580,000 budget. All math is 32-bit integer.

### What to check

1. Drum or synth track, Groove Kit, default preset, song at 88 BPM: press play and hold C. The loop should start in time and end bar 2 with a fill.
2. Hold different keys and both octaves. Lower keys are steady grooves, upper keys busier.
3. Turn Style through the seven styles, then to hh shot. The screen text should change to ONE SHOT. Each key should play one hit. Play F# while A# rings: the open hat should cut off.
4. Play softly and hard. Level should follow velocity.
5. Change tempo between 75 and 120 BPM while holding a key. It should stay locked.

### Sample credits and licence

Drum samples: Virtuosity Drums, as published at https://github.com/studiorack/virtuosity-drums, released under CC0 1.0 Universal (public domain dedication). No attribution is legally required; it is given here with thanks. Processing: trimmed, faded, resampled to 32 kHz and converted to 16-bit by tools/kit015_samples.py. No other samples are used.

Engine code, patterns and DSP: original, built on the Open-XY SDK by etcetc000 and contributors (MIT).

# Earlier kits (014c and before)

The notes below are kept from kit 014c. The Groove player they describe is removed in kit 015.

# Kit 014c

Kit 014c fixes Groove playing only one sound per held key.

- Groove now places each part's pad relative to the key you press, the way Scale Chord builds its chords from the pressed note. Before, pads were placed from the keyboard octave, and at some octaves every hit landed on the same top note, so only one sound played.
- In now mode every hit of the key plays at once, one pad per part.
- In tight, human and loose, the first step's hits play on key down and later hits are delayed in player steps.

## What to test

1. Drum track, Groove, Knob 4 on now: hold a key. You should hear kick, snare and hats together.
2. Change the track octave up and down and repeat. It should still play several pads.
3. Knob 4 on tight: hold a key. If you hear the first hits but nothing after them, delayed hits do not work on the device.

# Kit 014b

Kit 014b is kit 014 with a fix for Groove playing nothing when a key is held.

- The first hit of every Groove key now always sounds on key down (delay 0), the same way Scale Chord plays its chord.
- Repeated pitches at the same step are merged into one hit.
- New Mode on Knob 4: **now**. It plays every hit of the key at once, as one chord. This is a test mode: if now sounds but tight does not, the delayed hits are the problem, not the track.
- The set modes moved one position: setkick, setsnr, setchat, setohat, setperc now come after now.

## What to check

1. On the drum track with Groove, set Knob 4 to now and hold a key. You should hear a stack of drum pads.
2. Set Knob 4 to tight and hold a key. You should hear the half bar.
3. If nothing sounds in either mode, put Scale Chord on the drum track and hold a key. If Scale Chord is silent there too, players do not run on drum tracks on this firmware. In that case use Groove on a synth or sampler track instead.

## OP-XY kit 014 (Kieran)

Machines (16): Macro Osc, Karplus, 2op FM, Phase, Piano, Shaker, Choir and Upright Bass engines, the Vocal Tune (with harmonizer) and Cloud (granular) sample engines, the Scale Chord and Groove players, and Ring Mod, Ping Pong, Tape character and Tape Loop send effects.
Built for stock OP-XY OS 1.2.0. The device shows OPEN 0.0.2-1.2.0 when it starts.
Source: local branch kit-014 (open-xy SDK fork, MIT, etcetc000 and contributors). Not pushed.

Fixed kit: the builder installs the full set of machines only. It offers no partial selection.

## Kit 014

New in kit 014:

- Groove (player 9, page 94): one drum groove player with seven styles (hip hop, alt, R&B, rock, reggaeton, latin, funk), each with a whole keyboard of patterns, part toggles, Feel and Human, pad remap and velocity scaling. Full details below.
- Brushed Kit (engine 44, page 91) and Boom Bap Kit (engine 45, page 92) are removed. Their grooves live on in Groove (hip hop and alt/R&B styles). Their numbers stay reserved in layout.json, so no other machine can take them; tracks saved with them will need rebuilding with Groove on a drum track.
- Cloud fix: the Shift row captions are now at most 8 characters each, "Sz200 S1" (Size in ms, Spray step) and "D5 Sh0" (Density step, Shimmer step; F at the end means frozen). Kit 013's longer captions jumbled on screen. Sound and controls are unchanged.
- Upright Bass Key fix: Key shows note names (C, Db, D through B) in the screen header and major or minor is its own choice on Mode (play, major, minor). See Upright Bass.
- Upright Bass fix: about 10 dB louder (makeup gain 12 instead of 3) with a soft knee and a ceiling per voice, so it now sits level with Piano and Choir (RMS about -26 dBFS against -36 before) and a four note chord still does not clip.

Every other machine keeps its numbers and page, and the kit 009, 010, 010b, 011, 012 and 013 layouts all build.

### Groove (player 9, page 94)

One drum groove player with seven styles. Each style fills the whole keyboard with patterns: 12 grooves, one per key from F to E. The lower octave plays the first half bar of a groove (steps 1 to 8) and the upper octave plays the second half bar (steps 9 to 16), so the two keys together make the whole one-bar groove. Keys above repeat every 24 keys. Put Groove on a drum track (stock drum kit or your own pads): each press sends the pattern's hits to the drum pads you chose, locked to the sequencer steps (so to the project tempo).

Tuned for 75 to 120 BPM, with the sweet spot at 85 to 90.

#### Controls (the exact 16 action map)

Players in this SDK only receive the four knob turns. Knob presses, Shift turns and Shift presses are not routed to a player (the player API has no input for them), so they keep their stock OP-XY job and Groove does nothing with them.

| Action | Knob 1 | Knob 2 | Knob 3 | Knob 4 |
| --- | --- | --- | --- | --- |
| Turn | Style: hiphop, alt, rnb, rock, regton, latin, funk | Parts: KSHP, KSH, KS, KH, SH, K, S, H, P, KSP, KHP, SHP, KP, SP, HP | Feel 0 to 100 percent (default 55) | Mode: tight, human, loose, setkick, setsnr, setchat, setohat, setperc |
| Press | stock (not available to players) | stock | stock | stock |
| Shift + turn | stock (not available to players) | stock | stock | stock |
| Shift + press | stock (not available to players) | stock | stock | stock |

Parts letters: K kick, S snare, H hats (closed and open), P perc. A part that is off is not played.

Feel: at low values the groove is straight and dry (light ghost notes drop out below 25 percent). Going up, off-beat 16ths get softer against the beat (a velocity swing, the lazy 85 to 90 BPM pocket) and ghost notes get louder. Human: Mode human adds up to plus or minus 24 velocity per hit, loose plus or minus 48, from a fixed random table so a key always plays the same way; tight plays exactly as written.

Velocity: how hard you press the key scales the whole pattern (accents and ghosts keep their balance), from very soft to as written at full velocity.

#### Styles and patterns per key

| Key (lower octave F to E, upper octave same key) | Hip Hop (hiphop) | Alt/Indie (alt) | R&B/Neo-soul (rnb) | Rock (rock) | Reggaeton/Dembow (regton) | Latin (latin) | Funk (funk) |
| --- | --- | --- | --- | --- | --- | --- | --- |
| F | boombap | altback | neoghost | backbeat | dembow | bossa | jb funk |
| F# | swungbap | train | dillabr | rock8 | dembow2 | samba | linear |
| G | funkydrm | ballad | slowjam | halftime | perreo | songo | cold swt |
| G# | amen | six8alt | shuffle | fouroflr | dembhalf | cascara | chicken |
| A | impeach | motorik | soul128 | ridebeat | pegao | clave32 | popcorn |
| A# | halftime | indiedsc | newjack | grunge | moombah | clave23 | pocket |
| B | dilla | drive8 | trapsoul | shuffle | dembrim | mambo | disco |
| C | lofi | tomgroov | quietstm | punk | dancehal | cumbia | gogo |
| C# | think | floorhlf | neorim | tomtom | sparse | baiao | nola 2nd |
| D | rimshake | indieshf | bounce | ghostrck | rolldemb | tumbao | slapbak |
| D# | fill rsh | dancpunk | gospchop | fill 16 | fill reg | fill tim | fill fnk |
| E | fill chp | fill bld | fill bel | fill crs | fill brk | fill cnc | fill hat |

The last keys of each style (D# and E, the "fill" names) are drum fills.

#### Default pads and how to remap

Defaults follow the stock drum kit layout, counted from the lowest key of the track:

| Part | Default pad (key) |
| --- | --- |
| Kick | F1 (first key) |
| Snare | G1 (third key) |
| Closed hat | C#2 (ninth key) |
| Open hat | D#2 (eleventh key) |
| Perc (rim) | A1 (fifth key) |

To remap: turn Knob 4 to setkick (or setsnr, setchat, setohat, setperc). The screen says "press pad for kick (now F1)". Press the key whose drum sound you want for that part: it sounds normally and is stored. Turn Knob 4 back to tight, human or loose to play grooves again. The remap is kept while the track keeps Groove selected, but it is not saved with the project and goes back to the defaults when the project reloads or Groove is selected again (player state is cleared on select and is not saved in this SDK).

#### Screen

Black and white, built only from closed paths (no ellipses). A grid of 3 rows by 8 steps shows the last half bar played: squares for kick (top row), diamonds for snare (middle), triangles for hats and perc (bottom). The text line shows the groove, half and pad, for example "sparse B C#2  3 hits"; the header shows style, set, feel and mode. When idle it shows the style's first groove.

#### SDK limits and the closest design

- Only knob turns reach a player, so all four controls are turns (above).
- A press can schedule at most 8 hits, each delayed in player steps; there is no clock or transport for players, so a pattern cannot loop on its own. That is why each key plays one half bar: sequence the keys (or hold them in a sequencer step pattern) to make longer grooves. When a half bar has more than 8 hits, the most important are kept (kick, snare, open hat, on-beat hats, perc, ghosts, off-beat hats).
- Swing in time needs player steps finer than a 16th. If the device runs one player step per 16th (expected), Feel works as velocity swing and ghost density. kStepUnit in player.cpp sets steps per 16th; at 3 or more Feel also delays the off-beat 16ths, and at 6 or more Human and loose also nudge timing.
- Releasing the key releases the hits it played; a short note can cut the half bar short.
- Player state (the pad remap) is not saved.
- The screen can show 24 dots and one text line, so the grid is the animation.

#### Tests

Host tests (machines/groove/tests/player.cpp): 24 patterns per style and 168 in all, labels at most 8 characters, at most 8 hits per press, default pads, timing at 75, 88 and 120 BPM (a 16th is 200, 170.45 and 125 ms), part toggles, remap (it follows the octave), velocity scaling, tight against loose, feel, key wrap and the display. A player has no audio block, so its CPU is per key press only (at most 8 hits picked from at most 16 steps), far below the 580,000 cycle block budget. Object size 19 KB.

#### Credits

Groove is original code (MIT) for etcetc000's Open-XY SDK, whose credits and license it keeps. The grooves are written from common public-domain drum idioms (boom bap, dembow, bossa, songo, go-go and so on); no samples and no copied recordings.

## Machine numbers

| Machine | Kind | Number | Page |
| --- | --- | --- | --- |
| Macro Osc | engine | 26 | 83 |
| 2op FM | engine | 34 | 82 |
| Karplus | engine | 36 | 84 |
| Phase | engine | 37 | 87 |
| Piano | engine | 38 | 88 |
| Shaker | engine | 39 | 89 |
| Choir | engine | 43 | 90 |
| (Brushed Kit, removed) | engine | 44 reserved | 91 reserved |
| (Boom Bap Kit, removed) | engine | 45 reserved | 92 reserved |
| Upright Bass | engine | 46 | 93 |
| Vocal Tune | sample engine | 40 | 7 |
| Cloud | sample engine | 42 | 7 (stock drum sampler page) |
| Scale Chord | player | 7 | 85 |
| Groove | player | 9 | 94 |
| Ring Mod | send effect | 1 | 21 (FX) |
| Ping Pong | send effect | 8 | 21 (FX) |
| Tape (character) | send effect | 11 | 21 (FX) |
| Tape Loop | send effect | 21 | 21 (FX) |

## Make the firmware

1. Open opxy-builder.html in a web browser. It works offline.
2. Give it the os.ldr file from stock OS 1.2.0. No other version works.
3. This is a fixed kit: all 16 machines are always selected and the checkboxes are locked. Download the result.
4. Keep a copy of stock OS 1.2.0 in case you want to go back.

## Flash steps

1. Hold COM while switching the OP-XY on to open te-boot. It must show "3. dev menu". If not, enable it with the builder's dev menu helper.
2. Press track 3 for "3. dev menu", then track 3 for "3. mtp file transfer (windows)" or track 2 for "2. mtp file transfer (mac)". Wait for "mtp mode active".
3. Copy the files from the downloaded package to the device: os.ldr to /os.ldr, content/op1_factory.json to /content/op1_factory.json, and each content/display and content/presets file to the same path. Replace existing files and keep the other content.
4. Press track 2 for "2. exit".
5. Press track 5 for "5. write os to boot partition", keeping the OP-XY on power. When "firmware written ok!" appears, switch it off and on.
6. Check that it shows OPEN 0.0.2-1.2.0 at start.

## Recovery (te-boot)

If the OP-XY misbehaves or you want stock back: hold COM at power-on to open te-boot, then press track 1 to install the official firmware. Afterwards you can turn the dev menu off with the builder's Disable dev menu button.

Keep layout.json. It holds the machine numbers your projects use. Pass it with --layout to future builds so old projects still open with the right machines.

## Macro Osc (engine 26, page 83)

47 Braids oscillator models (Emilie Gillet). Press any encoder to switch pages.

| Knob | Page 1 | Page 2 |
| --- | --- | --- |
| 1 | Model | Bits (2 to 16) |
| 2 | Timbre | Rate (2.76 to 44.1 kHz) |
| 3 | Color | Drift |
| 4 | FM Ratio (0.5 to 8x) | FM Depth |

## Karplus (engine 36, page 84)

| Knob | Control | Effect |
| --- | --- | --- |
| 1 | Bright | Soft finger pluck to hard bright pick |
| 2 | Pick | Pluck point: twangy at the bridge to hollow at the middle |
| 3 | Damp | Glassy ring to dull muted string |
| 4 | Detune | Second string up to about 25 cents apart |

## 2op FM (engine 34, page 82)

| Knob | Control | Mapping |
| --- | --- | --- |
| 1 | Ratio | Modulator/carrier ratio, 0.5 to 16 |
| 2 | Amount | Phase modulation depth |
| 3 | Feedback | Modulator feedback |
| 4 | Decay | Modulation decay time |

## Ring Mod (effect 1, FX page)

| Knob | Control | Mapping |
| --- | --- | --- |
| 1 | Freq | Carrier 0.25 Hz to 4096 Hz, exponential (default 75) |
| 2 | Shape | Sine to square |
| 3 | Low Cut | High-pass before modulation, 0 bypasses |
| 4 | Dry | Source dry signal through the stock mixer |

## Ping Pong (effect 8, FX page)

| Knob | Control | Effect |
| --- | --- | --- |
| 1 | Size | Note length between repeats, 1/32 to 1/2, tempo synced |
| 2 | Fine | Time offset up to 50 ms either way |
| 3 | Feedback | Repeat crossing to the other side, up to 95% |
| 4 | Dry | Source kept by the stock mixer at full send |

## Vocal Tune (engine 40, page 7)

Sampler for vocals: snaps a recorded pad to a key and scale, shifts formant, and adds 0, 1 or 2 backing voices. Works on recorded pads, not live input.


| Encoder | Plain | Shift |
| --- | --- | --- |
| 1 | Pitch in ten-cent steps. Press resets | Stock reverse |
| 2 | Stock start trim | Turn: key. Press: strength Open, Subtle, Medium, Hard |
| 3 | Stock end trim | Turn: scale Major, Minor, Chrom. Press: harmony 0, 1, 2 |
| 4 | Turn or press: play mode key, oneshot, loop | Turn: stock volume. Press: formant preset 0, +3, +6, -6, -3 |

Captions: row one shows key and strength, for example `A Medium`. Row two shows scale, harmony and formant, for example `Minor +2 F-6`.

### Live parameters

The eight live slots follow the Timestretch layout so the stock page overlays line up: pitch, start, end, play (loop, pad, play), reverse (off, pad, on), formant (plus or minus 12 semitones, added to the preset), tune mix (0 dry to 1 tuned) and volume.

### Play modes

Loop wraps between the trims; the seam fades out and back in over a few milliseconds. Key and oneshot both play to the end trim: the engine does not receive note off, so a true gated key mode needs an OS hook. The end trim fades out over about 10 ms instead of stopping hard, and every start fades in over about 3 ms.

### Kit 008: CPU

Overload on hardware: one Vocal Tune voice cost far more than any other machine. In a Blackfin simulator run (a sung phrase, 6 pad settings by 3 transpositions), the lead alone averaged about 64,500 cycles per block and two backing voices reached about 308,000 worst case, out of roughly 580,000 for the whole device. Kit 008 removes per-sample divides and repeated work (glide coefficient, pitch lookup, backing voice spacing, sample reads). The output is bit for bit the same as kit 007. Lead alone is now about 52,100 average, two voices about 124,000, and the worst case over all runs fell from 308,258 to 165,341 cycles. It is still the heaviest machine: keep to one or two Vocal Tune pads sounding at once with harmony on.

Background work: the pitch analysis already runs once per sample in the background, with the "Preparing sample" popup as the busy sign; until it finishes the pad plays dry. A full bounce of the tuned result was not added, because the tuned sound depends on the pad's Tune settings, the note and the live Pitch, Formant and Mix knobs, and the SDK only re-runs background work when the sample changes. The dry sample is never changed.

### Kit 007 fixes

Pops between notes: kit 006 snapped each new grain onto the source pitch mark whenever the shift came within 8 cents of zero, so on every note change and vibrato crossing grains started partway through their window. Grains now follow one continuous chain, source marks repeat or skip one period when they drift, and windows always overlap. On a sung sweep test the click energy fell from about 0.11 to 0.14 (14 to 16 events) to 0.00007 or less (0 events) at Subtle, Medium and Hard.

Formant: -3 and -6 sounded like +3 and +6 because both signs used the same ratio. Negative presets now use the reciprocal, so the brightness goes -6, -3, 0, +3, +6 from dark to bright.

## Phase (engine 37, page 87)

Mono phase-distortion oscillator. At zero Drive and a centered Bend it is a sine. Up to eight notes.

| Knob | Id | Default | What it does |
| --- | --- | --- | --- |
| 1 | drive | 0 | How far the phase corner moves away from center |
| 2 | bend | 50% | Where the corner travels (early or late in the cycle) |
| 3 | level | 70% | Output level |
| 4 | color | 0 | Mix of the second harmonic |

No filter, envelope or unison.

Screen: one cycle drawn as an orbit, cosine across and the bent sine up. At zero Drive it is the plain grey circle. Drive and Bend pull it into a leaning teardrop with a sharp corner where the phase kinks, Color folds a second loop in, and Level sets its size. Each note start swells the orbit and spins the white dot. While keys are held it settles to a gentle hum, and after the last release it shrinks back and slows.

Velocity (kit 008): level now follows velocity. Kit 007's built-in default preset had the OP-XY's velocity sensitivity at 0, which switches velocity off. Phase now ships Default, Sine and Bend presets with sensitivity at 70 percent, like the factory presets. Brightness from velocity is not in the engine, because the SDK gives the voice no velocity value; route velocity to Drive or Color in the preset's modulation page for that.

## Piano (engine 38, page 88)

A sample-free piano synth for the OP-XY (engine 38, page 88), built with the Open-XY SDK by etcetc000. It is a modal model of a struck stiff string: six partials with the slight upward stretch of a real piano string, each ringing on two strings a few cents apart. Upper partials die faster than low ones, the second string decays at half the rate so the tail lingers like a piano's aftersound, and a short filtered noise gives the hammer. High notes fade sooner than low ones. The OP-XY's own envelope still shapes the release.

| Knob | Control | Effect |
| --- | --- | --- |
| 1 | Tone | Soft felt hammer (dark, few overtones) to a hard, bright strike. Applies on the next note |
| 2 | Decay | Ring time, about 0.4 s to 14 s at middle C |
| 3 | Chorus | Detune between the two strings, up to about 6 cents: still to honky tonk |
| 4 | Level | Output level |

Presets: Default, Grand, Felt, Honky.

Screen: a struck ring. Every note start drops the square hammer onto it and sets it vibrating. Tone sets how many lobes it vibrates in (two for felt, eight for a hard hammer) and how high it is struck. Decay sets how slowly it settles, using the same ring time as the sound, and with every key up the damper settles it four times faster. Chorus turns a grey twin ring against the first and makes it beat. Level sets the size.

Velocity (kit 008): level now follows velocity, with the same root cause and fix as Phase (sensitivity was 0 in the built-in default). Presets Default, Grand, Felt and Honky ship with sensitivity at 70 percent. A kit 007 project keeps its saved preset: load a new preset or raise velocity sensitivity in the preset settings. For a harder, brighter hammer on hard hits, route velocity to Tone in the preset's modulation page; Tone applies on the next note, so each note picks up its own velocity.

The voice is mono. Chorus gives width as beating between the strings rather than stereo spread.

CPU (kit 008): the render now runs partial by partial with its state in registers. The output is bit for bit the same as kit 007 (same hash on host and in the Blackfin simulator), and simulated cycles per voice block fell from 17,543 average and 20,061 worst to 12,471 and 14,705. Partials above Nyquist or faded out are skipped.

MIT, copyright 2026 Open-XY contributors.

## Scale Chord (player 7, page 85)

Pick a track, open its player page and choose Scale Chord. Any instrument works behind it.

- Knob 1, Key: C through B. One click, one key.
- Knob 2, Mode: Scale, Chord or Off.
- Knob 3, Scale: major, minor, Dorian, Mixolydian, harmonic minor, major pentatonic, minor pentatonic. The list repeats three times across the knob, so each change needs a third of the old turn.
- Knob 4, Variation: triad, drop, 7th, sus2, sus4, low 3rd, add9. Drop is the triad with its fifth moved an octave down, under the root: C E G plays as G (below) C E.

Every chord tone keeps the velocity of the note that triggered it, live or recorded.

## Tape (effect 11, FX page)

Tape character send effect. Stereo wet return.

| Knob | Id | Default | What it does |
| --- | --- | --- | --- |
| 1 | wow | 0% | Slow (about 0.5 Hz) pitch drift from a smooth, interpolated, modulated delay. Zero is no delay at all. Full swings the delay between 0 and 12 ms |
| 2 | flutter | 0% | Faster (about 6 Hz), smaller drift, up to 0.6 ms of swing, from the same clean delay |
| 3 | drive | 0% | The only control that saturates. Gain 1x to 4x into a soft cubic shoulder, blended in from zero, so a little drive is a little warmth |
| 4 | dust | 0% | Sparse, soft crackle that follows the input level, up to about 40 a second. Silence stays silent |
| 5 | tone | 100% | One-pole low pass. Full is fully open (bypassed). Zero is dark |
| 6 | dry | 0% | Stock dry mixer. At zero and full send the return replaces the source, like an insert. Raise it to blend in the untouched source |

With Wow, Flutter, Drive and Dust at zero and Tone at full, the return is the input, bit for bit.

Kit 008 fix: Wow and Flutter distorted on the device. The delay line kept only the top 16 bits of each sample, and a device send is quiet, so the delayed signal was a few coarse steps. The line now keeps full 32-bit samples (2048 frames per side, about 46 ms; full Wow swing is now up to about 12 ms within that).

Kit 007 fix: kit 006 always read the wet path 14.5 ms late, and with Dry at its old 100% default the mixer added that late copy to the source, which colored and buzzed everything. Now every control starts from an exact bypass.

## Tape Loop (effect 21, FX page)

Send effect. Effect 21 on the stock FX page. It asks for a 352800 byte send scratch buffer (the size Ping Pong runs on the device) and for the tempo.

Tape Loop always records the send into a full-rate ring of full 32-bit samples, 2 seconds long. A Size longer than about 1.7 seconds (for example 1 bar below about 140 BPM) is halved to fit. A pattern of 8 steps decides when it latches. Each step is one Size long. When a latched step starts, the last Size of audio is captured and repeats until an unlatched step lets the live send through again. This is the same idea as the rhythmic repeat on the OP-XY tape button 6, built as a send effect.

Steps follow the song position while the sequencer plays, so latches land on the grid. When stopped, an internal clock at the current tempo (120 BPM if none) keeps the pattern running.

When the pattern is off, the wet return is the live send. Dry defaults to 0, so at full send the effect acts like an insert.

### Knobs

| Knob | Id | Default | What it does |
| --- | --- | --- | --- |
| 1 | size | 1 beat | Step and loop length: 1:16, 1:8, 1 beat, 2 beats, 1 bar, 2 bars, 4 bars |
| 2 | pattern | alt | Latch pattern over 8 steps (see below) |
| 3 | decay | 100% | Level kept on each repeat. Full repeats forever, lower fades the loop out |
| 4 | level | 100% | Wet return |
| 5 | dry | 0% | Stock dry mixer |

### Patterns

Steps are written 1 to 8, x is latched, - is live.

| Pattern | Steps |
| --- | --- |
| off | - - - - - - - - |
| hold | x x x x x x x x |
| alt | - x - x - x - x |
| 3 on 1 | - x x x - x x x |
| 1 on 3 | - x - - - x - - |
| 2 on 2 | - - x x - - x x |
| push | - - - x - - - x |
| gallop | - x x - x x - x |

Hold latches as soon as it is selected and stays latched.

### Details

Live and loop crossfade over 128 samples, and each loop seam fades over 256 samples, so latching and looping do not click. A size longer than the ring halves until it fits. Recording freezes while a loop plays, so it is never overwritten. The effect counts what it has written and never plays older scratch. Outside a send slot the buffer is empty and the return is silence. The audio is mono. Host estimate is about 6,600 instructions per block.

Kit 008 fix: the loop came back silent or gritty while the live send was clean. The ring stored 16 bits per sample, so at the quiet level a device send carries, the captured loop was only a few bit steps. It now stores full 32-bit samples.

Kit 007 fix: kit 006 stored the loop at half rate, so bright sounds in a latched step came back aliased into grit, and the write head could run into the captured loop. The ring now records at full rate, freezes while latched, and crossfades the loop seam. A 9 kHz tone in a latched step now comes back clean.

## Shaker (engine 39, page 89)

A shaker synth for the OP-XY (engine 39, page 89), built with the Open-XY SDK by etcetc000. Hold a key and it shakes: each key plays its own pattern, locked to the project tempo, for as long as you hold it, so the note length is the pattern length (a sequencer step of any length plays that much of the groove). The sound is original code after Perry Cook's PhISEM idea (Physically Informed Stochastic Event Modeling, 1997): each stroke puts energy into a set of beads, collisions arrive at random with a level that follows the energy left, and the shell's resonances filter them. Forward strokes slam in fast, bright and loud; back strokes swish in slower, softer and darker. Every hit varies a little in timing, level, tone and bead density, so no two strokes are the same.

Page 1 (press to switch pages):

| Knob | Control | Effect |
| --- | --- | --- |
| 1 | Tone | Shell resonance, about 10 semitones down to 10 up |
| 2 | Swing | Delays every other grid step, up to a triplet feel |
| 3 | Human | Timing drift up to about 3 ticks (15 ms at 120 BPM), plus a little level drift |
| 4 | Vary | Per-hit change of level (up to about 35 percent), tone (about 2.5 semitones) and bead density |

Page 2:

| Knob | Control | Effect |
| --- | --- | --- |
| 1 | Material | egg (bright, short), tube (two ringing resonances, longer swish), cabasa (dense, crisp), seeds (sparse, woody) |
| 2 | Grain | Bead count, two octaves fewer to two octaves more collisions |
| 3 | Stroke | Contrast between forward and back strokes: level, build time and tone |
| 4 | Level | Output level |

Patterns by note name (96 ticks per quarter; the octave only shifts brightness, about 3 semitones per octave from C4):

| Note | Pattern | Note | Pattern |
| --- | --- | --- | --- |
| C | 8ths | F# | push-pull, back strokes accented |
| C# | 16ths | G | quarters with a ghost return |
| D | swung 16ths | G# | ghost 16ths, accents on the beat |
| D# | 8th triplets | A | gallop |
| E | 16th triplets | A# | samba, accent on the last 16th |
| F | offbeat accent | B | 32nd roll with a two-beat swell |

Presets: Default (egg), Tube, Cabasa, Seeds, Loose. All ship with velocity.sensitivity 22937.

### Tempo and transport

Shaker reads the tempo and transport the way Tape Loop does (SDK 1.3 synth transport, added in kit 009). While the song plays, patterns lock to the song position: a key pressed up to 6 ticks late still plays the hit it meant, and a locate or loop jump moves the pattern with the song. When stopped, the pattern starts at the key press at the project tempo.

### Velocity

The engine is not given velocity (only pitch, knobs and transport), so velocity sets intensity through the stock level stage with sensitivity 22937. Accents within the pattern are the engine's own.

### Screen

The shell of the chosen material shakes from side to side while a key is held, tilting into each stroke. At each turn the beads fly to the far end; Grain sets how many beads show (3 to 8). With every key up the shell settles and the beads drop to the bottom. Reduced motion keeps it still. The screen is given no tempo, so the shake runs at about four strokes a second rather than following the BPM.

### Release (fixed in kit 010)

In kit 009 the shaking kept going for a moment after you let go. The OP-XY stores amp release inverted (higher is shorter) and the presets shipped 2000, which is a long tail. All five presets now ship with the shortest release (32767), so the shaking stops at once when you release the key. The engine gets no note off, so the amp release is what ends the sound. Tracks saved with kit 009 keep their old value: load the preset again, or turn the amp release to its shortest.

CPU: in the Blackfin simulator (tools/devsim/synth.sh with EXTRA=-DSYNTH_TRANSPORT) one voice averages 5,088 cycles per block, worst 7,559, with the same output hash on host and simulator (1675636833). Eight voices at the worst case are about 60,500 cycles of the 580,000 per block budget. All math is 32-bit integer; the only divides are per hit or per tempo change.

MIT, copyright 2026 Open-XY contributors. The PhISEM concept is Perry R. Cook's (Computer Music Journal 21:3, 1997); no STK code is used.

## Cloud (sample engine 42, page 7)

A granular sampler for the OP-XY (sample engine 42; kit 009 used 41 on page 2), built with the Open-XY SDK by etcetc000. Since kit 010 it plays on the stock drum sampler page (page 7), the way Vocal Tune does, so all of its grain controls sit on the encoders. Record or load a sample onto a pad as for the stock drum sampler, then play the pad: up to sixteen grains at a time read the sample near a moving playhead, each shaped by a Hann window so grains fade in and out with no clicks. Spray scatters each grain's position, pitch and stereo place; Shimmer layers octaves, and Freeze stops the playhead to hold one moment as a cloud. Each pad keeps its own grain settings, and replacing a pad's sample keeps them.

### Encoders (drum page, kit 013)

Kit 013 reworks Cloud after the kit 012 hardware report (the cloud was barely audible and sounded like the dry sample). It now starts as a lush pad: 200 ms grains, about ten at once, a slow quarter-speed scan, light detune and a wide stereo spread. No control needs a push and turn: a turn while the encoder is held does the same as a plain turn.

| Encoder | Turn | Press |
| --- | --- | --- |
| 1 | Pitch, ±12 semitones in 10-cent steps (stock) | Resets pitch (stock) |
| 2 | Start marker (stock): the start of the window grains read from | |
| 3 | End marker (stock): the end of that window | |
| 4 | Position, 16 steps across the window | Freeze on or off |
| Shift 1 | Reverse (stock) | |
| Shift 2 | Size, 16 steps: 20, 28, 40, 55, 75, 100, 130, 165, 200, 240, 280, 320, 360, 400, 450, 500 ms | Spray, steps 0, 1, 2, 3, then back to 0 |
| Shift 3 | Density, 8 steps: 2, 3, 4, 6, 8, 10, 12, 16 grains at once | Shimmer, steps 0, 1, 2, 3, then back to 0 |
| Shift 4 | Volume (stock) | Back to the defaults (Freeze is kept) |

The Shift row's two captions show the settings in at most 8 characters each (kit 014), for example "Sz200 S1" (Size in ms, Spray step) and "D5 Sh0" (Density step, Shimmer step; an F at the end means frozen). Defaults: Position 0, Size 200 ms, Density 5 (10 grains), Spray 1, Shimmer 0, Freeze off.

What the controls do:
- Position sets where in the window the cloud sits, added to the playhead. With Freeze on it picks the one moment the cloud holds.
- Size is the grain length. Short sizes give a buzzy, rhythmic texture; long sizes give smooth pads.
- Density is how many grains overlap. Level stays even (about 1/sqrt of the overlap).
- Spray scatters each grain. At 0 the cloud is clean and near the center. At 1 there is ±9 cents of detune, a small position scatter and a wide stereo spread (the default). At 2 there is ±28 cents and more scatter. At 3 there is ±90 cents, a quarter of the window of position scatter and full width.
- Shimmer adds pitch layers. At 1 a quarter of the grains go up an octave. At 2 the grains split between the root, an octave up and an octave and a fifth up. At 3 they split between an octave down, the root and an octave up.
- Freeze stops the playhead. When it is off, the playhead scans at a quarter of the source speed, so a sample stretches into a slowly evolving pad.

Pitch and keys: the pad pitch (encoder 1), the track transpose and the octave of the key played set the grain read speed, as on Vocal Tune. The playhead speed does not change with pitch, so pitch and time stay separate. Voices are polyphonic: every key press is its own cloud. Page 7 is the stock drum page, which maps each key to its own pad (24 pads). A sample therefore plays only from its own pad, and other keys play other pads. The SDK only passes whole octaves of the played key (drum transpose), so a page 7 engine cannot play one recording chromatically across the keyboard. Engine 41 (the kit 009 page 2 Cloud) stays reserved and is not in the firmware, so there is no chromatic granular cloud in this kit. Engine 42 must stay on page 7, because padSettings (the saved grain settings per pad) and the drum encoders only exist there.

Reverse (Shift encoder 1, or a reverse parameter lock) plays every grain backwards and runs the playhead backwards through the window. In kit 009 on page 2, reverse only flipped the grains, so a scanning cloud still moved forward and sounded much the same.

Parameter locks and LFOs reach the drum page's live slots: pitch, start, end, play, reverse, position (offset, up to half the range either way), size (offset, likewise) and volume. Play mode has no effect: grains run for as long as the pad is held, then the amp envelope releases (default attack 0, sustain full, release 20000).

Mono and stereo samples both work; a stereo sample is folded to mono per grain, then panned by Spray. Output is stereo.

Screen: Cloud shows the stock drum sampler page (waveform, trim and the captions above). Sample engines cannot have a custom or animated screen in this SDK; a custom display page is only available to synths and players, so the animated grain view was not added.

CPU (Blackfin simulator, tools/devsim/cloud.sh, one voice, 64-sample block, kit 013): 12,185 cycles worst with sparse grains, 42,062 worst at the defaults (about ten grains), and 59,084 worst with sixteen grains at full spray (the frozen 20 ms grain case). Host and simulator output hashes match (3443158469). Nine voices at the worst case stay under the 580,000-cycle block budget, and about thirteen at the defaults. All math is 32-bit integer. Per-sample work uses 16 by 16 multiplies, and divides run once per block or once per grain.

### Credits

Cloud is original code (MIT) for etcetc000's Open-XY SDK, whose credits and license it keeps. Granular synthesis after Curtis Roads (Microsound, 2001) and Barry Truax; the Position, Size, Density, Spray, Shimmer and Freeze controls follow the familiar layout of hardware granular modules. No third-party code is used.

## Choir

A choir synth for the OP-XY (engine 43, page 90), built with the Open-XY SDK by etcetc000. Eight wooden singers, bass to soprano, each with its own range, voice and habits. Every note goes to the free singer whose range suits it best, so a chord spreads across the choir. Inspired by Teenage Engineering's Choir (eight hand-made beech singers, after the 2007 Absolut Choir installation); this is original DSP, with no TE code or samples, made out of admiration for that instrument.

The sound: a glottal pulse (Rosenberg-style flow derivative) with per-period jitter and shimmer, a spectral tilt, breath noise in the open phase, four formant resonators morphing between a, e, i, o and u (published sung-vowel averages for bass, tenor, alto and soprano), a short consonant onset (m, n, l, d or t), and a wooden body resonance with two early reflections. Vibrato fades in after the onset.

Singer ranges (MIDI notes): bass 40-60, baritone 43-63, tenor 46-67, contralto 52-72, alto 54-74, mezzo 57-77, mezzo 59-79, soprano 61-81.

Page 1 (press to switch pages):

| Knob | Control | Effect |
| --- | --- | --- |
| 1 | Vibrato | Depth up to about 45 cents (kit 011: 70), fading in over about 0.37 s; each singer has its own rate (5 to 6 Hz) |
| 2 | Conson (Consonant) | Onset consonant: none, m, n, l, d, t |
| 3 | Vowel | a, e, i, o, u, morphing in between |
| 4 | Space | Wooden body resonance and early reflections |

Page 2:

| Knob | Control | Effect |
| --- | --- | --- |
| 1 | Fill | Extra singers: 0 sings only the pressed notes, full sings all 8 (3 keys at 0.4 sing 5) |
| 2 | Vary | How far each singer's vowel (up to 2 vowels) and consonant may stray from the knobs on each onset |
| 3 | Human | Per-singer timing, plus detune and drift kept within a few cents |
| 4 | Level | Output level |

### Variation per performance

On each onset every singer picks its own vowel and consonant inside the range Vowel, Consonant and Vary allow, with a cheap PRNG, and never repeats its last pick, so a repeated identical chord never sounds the same twice. Vary 0 sings exactly the knobs.

### Fill

Extra singers double the held notes in other octaves or intervals (octave down, octave up, fifth, fourth down, and so on), each with its own detune and timing, rendered inside the voices of the held notes. The whole choir is capped at 8 singers.

### Velocity, release

The engine is not given velocity, so velocity sets level through the stock level stage with sensitivity 22937. Presets use amp release 30000 (the device stores release inverted, 32767 is shortest) for a short tail.

Presets: Default, Ensemble, Hum, Chapel, Chant.

### Screen

The eight singers stand in a row in black and white. One lights up for each held note, more with Fill (the screen gets no pitches, so it lights them from the middle out rather than the exact singer). Lit singers open their mouths in the vowel's shape and sway; their mouths flutter with Vibrato, and a breath line over the choir swells with the number singing. Reduced motion holds still.

CPU (tools/devsim/choir.sh, Blackfin simulator, same hash on host and device, kit 012: 1720981997): all knobs maxed with 8 keys at full Fill, worst 131,561 cycles per 64-sample block (average 109,171; kit 011 was 120,138); one key at full Fill (8 singers) 91,858; default with 8 keys 130,561; one key 16,375. Budget is 580,000. All math is 32-bit integer with no per-sample divides.

### Kit 012 Choir sound notes

Only the sound changed. The knobs, screen, presets, variation per onset, Fill, layout and numbers are exactly as in kit 011, and each note still picks its own vowel.

- In tune. The tuning math was already exact (under 0.1 cent). What pulled notes off was Human: up to 32 cents of detune per singer, 8 cents of drift and 0.4 percent jitter per period. Now detune is at most 3 cents (doubles from Fill another 3), drift 1.5 cents and jitter 0.1 percent. Vibrato tops out at 45 cents instead of 70 and still fades in after the onset, so a held note starts centred.
- No ringing. Formant bandwidths are wider (80 to 260 Hz instead of 40 to 180), F3 and F4 sit at least 500 Hz apart so they never stack into one peak (kit 011 had pairs 200 Hz apart, the high-end build-up), upper formants are quieter, and a gentle one-pole lowpass near 8 kHz tops each voice. The wooden body moved from a narrow 420 Hz ring (28 Hz wide) to a broad 320 Hz warmth (about 140 Hz wide). Loudness per singer is trimmed to match kit 011.
- Clearer vowels. New sung F1 to F4 tables per voice type (bass and baritone, tenor, alto, soprano) for a, e, i, o and u, after Sundberg, Peterson and Barney and the classic sung-vowel tables, with smooth interpolation between vowels.
- Confident high notes. Formants follow the register: F1 rides just above the note when the note climbs past it, each formant keeps clear of the one below, bandwidths widen with pitch so no single harmonic rings, and F2 to F4 ease off above E4. The glottal pulse has a rounded closure (less buzz), the source lowpass darkens with pitch, and breath and consonant bursts get softer up high.
- Rich, warm baritone. Bass and baritone keep F2 to F4 lower under a strong, broad F1, with a darker, smoother source and less breath, so the low singers are full in the 200 to 500 Hz range without boxiness. The registers are balanced: the loudness spread across bass to soprano went from 10.3 dB to 3.3 dB.

Measured with tools/devsim/choir_measure.cpp (tests/test_choir_sound.py compares against kit 011 every run):

| Measure | Kit 011 | Kit 012 |
| --- | --- | --- |
| Tuning math error | 0.10 cents | 0.03 cents |
| Worst pitch error, default preset, any register (12 onsets each, averaged over 3 s) | 19.4 cents | 5.0 cents |
| Worst resonance peak (a harmonic over its neighbours) | 20.1 dB | 10.1 dB |
| Mean resonance peak | 12.2 dB | 7.3 dB |
| Energy above 4 kHz, all registers | -55.1 dB | -59.9 dB |
| Energy above 4 kHz, B4 and G5 | -47.4 and -43.9 dB | -55.6 and -57.7 dB |
| Loudness spread, bass to soprano | 10.3 dB | 3.3 dB |

MIT, copyright 2026 Open-XY contributors. Choir is a product of Teenage Engineering; this machine is an independent homage.

## Upright Bass (engine 46, page 93)

A woody plucked upright bass, synthesized with a Karplus-Strong string (no
samples): a finger pluck of coloured noise and a half-sine thump into a
damped delay loop, with a short finger click on top, slides into notes and a
dead-note thump. Two modes:

- Play: chromatic. Each new note plucks, sliding in from just below (Slide
  sets how far and how fast, 0 is a clean attack). With Mono playmode a new
  key while one is held slides there legato with no new pluck.
- Pattern (Mode major or minor): pick the Key, then hold any keyboard key: each of the 12 keys
  plays its own bass line in that Key, locked to the tempo (the song
  transport when it is playing). The octave you play in moves the line up
  (C4 and below is the low register). Tuned for 75 to 120 BPM, sweet spot 85
  to 90.

### Controls

| Page | Knob | Control | Job |
| --- | --- | --- | --- |
| 1 | 1 | Tone | Dark wood to bright gut (the loop filter) |
| 1 | 2 | Pluck | Soft thumb to snappy finger, with more finger noise |
| 1 | 3 | Slide | Grace-note slide in, and the legato glide time (up to about 180 ms) |
| 1 | 4 | Level | Output level |
| 2 | 1 | Mode | play, major or minor. Major and minor play the pattern lines in that scale. The screen header shows the word (play, major, minor) |
| 2 | 2 | Key | The 12 keys C, Db, D, Eb, E, F, Gb, G, Ab, A, Bb, B (C# is shown as Db and so on). The screen header shows the key with an m in minor, for example Am |
| 2 | 3 | Feel | Straight at 0, as written at 50 percent, deep swing and lay-back at 100 |
| 2 | 4 | Decay | How long a note rings, about 0.3 s to 4 s |

Press a knob to switch pages, then turn: Mode and Key never need push and
turn. Velocity comes from the stock level stage.

Full 16 action map (kit 014):

| Action | Knob 1 | Knob 2 | Knob 3 | Knob 4 |
| --- | --- | --- | --- | --- |
| Turn | Tone (page 1) or Mode (page 2) | Pluck or Key | Slide or Feel | Level or Decay |
| Press | Switch page 1 / page 2 (all four knobs) | same | same | same |
| Shift + turn | Same parameter at one tenth the rate (enums step as usual) | same | same | same |
| Shift + press | Stock (not available to the engine) | same | same | same |

Kit 014 fix: on the device kit 013 showed Key as a number. Since synth pages show enum values as numbers, the screen now writes the header itself on page 2: Mode as a word and Key as a note name. Major or minor moved from the Key list into Mode, so Key is just the 12 note names. Projects saved with kit 013 Upright patterns will read their old Mode and Key values differently: set them again.

### Lines per key (pattern mode)

| Key | Line |
| --- | --- |
| C | Root-fifth two-feel |
| C# | Walking |
| D | Neo-soul syncopated |
| D# | Boom bap line |
| E | Soul eighths |
| F | Octave pops |
| F# | Dilla long notes |
| G | Half-time ballad |
| G# | 12/8 soul ballad |
| A | Funk ghost sixteenths |
| A# | i to iv vamp |
| B | Walking ii-V |

Every line is two bars long. Roots sit from E1 up to D#2, like the low strings.

Presets: default (play, mono), walking (major, C), neo soul (minor,
A), thumb (dark and short), slap (bright and snappy).

### Screen

The outline of a double bass with its string down the middle. A note plucks
the string: it swings wide, then settles over the Decay time; Pluck sets how
far. While a pattern is held it keeps moving. The lamp at the top right is lit
in pattern mode. Reduced motion keeps the string still.

MIT. Built on the open-xy SDK by etcetc000.

### CPU

Blackfin simulator: pattern mode with every knob at full, worst 12,841 cycles per voice block (average 6,282); play mode worst 10,604 (average 6,132). Host and simulator hashes match. All math is 32-bit integer; the only divides are per note or per block.

## Known limits

- Vocal Tune key mode plays to the end trim: the engine gets no note off, so a held-key gate needs an OS hook.
- Scale Chord variations per step reset when a project reloads.
- Player notes sound on the next player step, not at the same moment as the key.
- Piano and Phase velocity: level follows velocity through the OP-XY's own velocity stage. The SDK synth interface passes no note velocity to the voice, so brightness and hammer hardness follow velocity only through the preset's modulation routing.
- Vocal Tune does not bounce the tuned result to memory; it renders live, now with less CPU (see Vocal Tune).
- Kit 014 is untested on a device. Check Groove: that it can be chosen on a drum track (page 94), that hits land on the 16ths at 75, 88 and 120 BPM against the metronome (if two hits flam together, kStepUnit is wrong), whether hits still pending are dropped when the key is released, part toggles, the pad remap, velocity, and the screen. Check Upright Bass level next to Piano with chords, and the Cloud Shift captions.
- Kit 013 checks still open: Upright pitch against a tuner, slides in Mono, and that pattern mode Key and Mode change from page 2; levels next to Shaker and Piano; and Cloud as a lush pad at its defaults, with Shift 2 and Shift 3 presses for Spray and Shimmer.
- Cloud on page 7 cannot play one sample chromatically (the drum page maps each key to its own pad), and engine 41 is reserved, not in the firmware.
- Cloud has no custom or animated screen: sample engines can only use the stock sampler pages (2 or 7), so it shows the stock drum sampler page with a caption.
- Cloud's grain settings are stepped (16 positions, 16 sizes, 8 densities, 4 spray and 4 shimmer levels) so they fit in each pad's saved word.
- Shaker's screen shakes at a fixed rate; the screen is not given the tempo.
- Choir kit 012 sound is untested on a device: check pitch against a tuner, that high notes (above E5) sound open, that the baritone is warm and not muddy, the level against kit 011, and that the top is not too dark with Space at 0. Choir kit 011 checks still apply: the sound and level, the singers screen, CPU with 8 keys at full Fill, whether the modwheel drives Vibrato, and the 30000 release. The screen lights singers from the middle out (it gets no pitches).
- None of the kit 008, 009 or 010 changes have been tested on a device yet. Still to check on the device: what a kit 009 project with a page 2 Cloud track shows now that engine 41 is gone; how short the shortest amp release really is on Shaker, Cloud's encoder bindings (E4, Shift E2 and E3, hold and press), its caption, reverse, and that Cloud pads stop when released. CPU numbers come from host estimates and a Blackfin simulator, not the device.
- The builder reopens only its own full-set builds (and stock OS 1.2.0); a partial build from an older kit is not recognized.

## Earlier kits

Fixed kit: from kit 009 on, the builder installs the full set of machines only. It offers no partial selection, and its export checks verify that one selection (about 25 seconds instead of hours). The firmware is byte for byte what the full selection gave before.

New in kit 013: three new synths that play like Shaker (hold a key and it plays a pattern locked to the tempo), and a reworked Cloud.

- Brushed Kit (engine 44, page 91): a synthesized brushed drum kit for alternative and R&B.
- Boom Bap Kit (engine 45, page 92): a gritty SP-1200 and MPC style hip-hop kit. No samples: every sound is synthesized.
- Upright Bass (engine 46, page 93): a woody plucked upright bass. Play mode is chromatic with slides; pattern mode plays a bass line per key in the Key you pick.
- Cloud (sample engine 42, page 7) is reworked after the kit 012 report that it was barely audible and sounded like the dry sample. It is now a lush pad by default, has up to sixteen grains, adds Shimmer, and needs no push and turn (see Cloud).

The kit 013 drum kits (removed in kit 014) were tuned for 75 to 120 BPM with a sweet spot at 85 to 90. Every existing machine keeps its numbers and page (Choir 43/90, Shaker 39/89), and the kit 009, 010, 010b, 011 and 012 layouts all build.

The builder no longer caps a fixed kit at 14 machines when it recognizes an open-xy OS it made: a fixed kit relinks only its one selection.

New in kit 012: the Choir sound is refined (see Choir, Kit 012 Choir sound notes): in tune, no ringing resonances, clearer vowels, confident high notes and warmer low singers. Its knobs, screen, presets, variation, Fill and numbers are unchanged, and every other machine is exactly as in kit 011. Kit 009, 010, 010b and 011 layouts all build.

New in kit 011: Choir (engine 43, page 90), a choir of eight wooden singers from bass to soprano, inspired by Teenage Engineering's Choir. Each note goes to the singer whose range fits it; every onset picks a fresh vowel and consonant per singer within the knobs' range, so the same chord twice never sounds the same; Fill adds singers in other octaves up to all eight (3 keys at Fill 0.4 sing 5). Page 1: Vibrato, Conson (consonant), Vowel, Space. Page 2: Fill, Vary, Human, Level. Every other machine keeps its kit 010b numbers, and kit 009, 010, 010b layouts all build.

New in kit 010: Shaker now stops as soon as you release a key (see Shaker, Release), and Cloud moved to the drum sampler page 7, where its grain controls are on the encoders and reverse really plays backwards (see Cloud).

New in kit 009: Shaker, a human-sounding shaker synth where each key plays its own pattern locked to the project tempo for as long as it is held, and Cloud, a granular sampler with Position, Size, Density, Spray, Freeze and Smear. The SDK gained synth transport (tempo and song position for synths, SDK 1.3).

Kit 010b fixes kit 010, which could not be installed: with your kit 009 numbers remembered by the builder (or a kit 009 layout.json loaded), it stopped with "cloud now asks for stock page 7; the layout holds another" and "Selection cannot be built". The builder keeps each machine's numbers for good so saved projects keep working, and it will not move a sample engine to another stock page under the same numbers. Cloud on page 7 is therefore a new machine to the builder (id cloudpad, sample engine 42). Engine 41 stays reserved for the kit 009 page 2 Cloud, so nothing else can take it. Every other machine keeps its kit 009 numbers. Your remembered numbers, your kit 009 layout.json and the layout.json in this zip all build now.

Cloud tracks saved on page 2 with kit 009 point at engine 41, which this firmware no longer contains, so rebuild them on a drum track with Cloud (page 7).
