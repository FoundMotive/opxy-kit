# Kit 028b

Branched from kit 028 (f96dfda). Finishes kit 028's scope: FM names on the
device, cleanup, and CPU/size. Every engine sounds exactly as in kit 028
(all render hashes identical).

## Names on the device

The OP-XY lists a machine by the type string it registers; the firmware has
no separate display-name field. Projects store machines by engine, effect and
page number, not by that string, so changing it does not break old projects.

Approach: definition.json has an optional "deviceName" (lowercase words,
8 characters or fewer, never a stock type). It becomes the registered type,
catalog type and preset type. The machine ID still names folders, code
symbols, the screen file and the .oxy companion, so nothing else moves. The
etcetc000 machines keep their short names.

| Machine ID | Builder name | Name on device |
|---|---|---|
| choir | FM Choir | fm choir |
| cloudpad | FM Cloud | fm cloud |
| groovekit | FM GKit | fm gkit |
| guitar | FM Gtr | fm gtr |
| phase | FM Phase | fm phase |
| piano | FM Piano | fm piano |
| scalechord | FM Chord | fm chord |
| shaker | FM Shakr | fm shakr |
| tapechar | FM Tape | fm tape |
| tapelite | FM Loop | fm loop |
| upright | FM Bass | fm bass |
| vocaltune | FM VTune | fm vtune |
| macroosc, karplus, fm2op, ringmod, pingpong | unchanged | unchanged |

The device shows lowercase (as stock does, e.g. "z lowpass"). Factory presets
are rewritten by the installer with the new type. User presets you saved
yourself under an old type (e.g. "choir") will not match any more; convert
copies with `tools/kit028b_rename_presets.py IN_DIR OUT_DIR` (offline, never
touches originals). Loading of the new names on real hardware is not yet tested.

## Cleanup

- machines/boombap, brushkit, groove moved to machines/_archive/ (not deleted;
  old kit 013/014 collections point there).
- choir .bak files renamed to machines/_archive/choir-*.kit013-backup.txt.
- kit028-audio/kit-028-README.md renamed to kit-028-README.copy-renamed.txt.

## CPU and size

| Engine | devsim worst / avg cycles (kit 028) | kit 028b | Sound |
|---|---|---|---|
| FM VTune live | 160,251 worst | same | identical |
| FM Choir (8 keys) | 131,561 / 109,171 | same | identical |
| FM Gtr pattern | 135,811 worst | same | identical |
| FM Piano | 81,424 / 69,541 | same | identical |
| FM GKit | 40,571 / 28,840 | same | identical |

No engine CPU change was made: no candidate rewrite was found that is
bit-identical, and anything that changes output was ruled out. All engines
are well under the 580K budget.

FM Gtr browser preview: 521,150 to 518,290 bytes (limit 524,288, headroom
3,138 to 5,998). Lossless: the preview's per-16-frame shift table is packed five
per 16-bit word (base 9) instead of two per byte (tools/kit028b_guitar_shift9.py).
Device build unchanged. Renders bit-identical to before on both paths.

## Tests

sdk.py check: 205 OK, 34 skipped; node 93 pass. Fixed-kit install tests pass
with and without the kit 026 layouts.
