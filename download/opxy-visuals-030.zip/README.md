# OP-XY Visuals (v30)

Reactive visuals for the Teenage Engineering OP-XY driven only by stock MIDI output. No firmware changes. Static site: open `index.html` (or serve the folder) in Chrome or Edge on desktop.

## Run
1. `cd visuals && python3 -m http.server 8080`, then open http://localhost:8080 (file:// also works in Chrome, but localhost is the reliable way to get the Web MIDI prompt).
2. Allow MIDI access when the browser asks.
3. Press H for the panel, pick the OP-XY input (or leave "all inputs"). Press D for demo mode without a device.

## OP-XY settings
1. Connect USB-C to the computer (or pair Bluetooth MIDI, see below).
2. Press COM, open the MIDI settings and turn on output of: clock, notes, other CC, velocity (COM > M3 devices toggles in TE guide terms).
3. Each track sends on its own MIDI channel. Default map: channel N = track N (1-8 instrument tracks T1-T8, 9-16 auxiliary tracks: brain, punch-in FX, external MIDI, external CV, external audio, tape, FX I, FX II). The COM > system > MIDI page also has an "active track channel" option; if you use it, notes for the selected track arrive on that channel, so remap in the panel. The map is saved in localStorage.
4. Press play on the OP-XY: clock drives BPM, steps and pulses; start/stop shows in the HUD.

### Bluetooth MIDI
- macOS: open Audio MIDI Setup > Window > Show MIDI Studio > Bluetooth icon, connect OP-XY. It then appears as a normal Web MIDI input in Chrome.
- Windows: Chrome Web MIDI does not reliably see BLE MIDI; use USB-C.
- iOS/iPadOS: Safari has no Web MIDI. Options: a Web MIDI browser app (for example "Web MIDI Browser" on the App Store) loading this page from a local server, or run it on a Mac and mirror/AirPlay the display. Not tested on iOS here.

## Controls
- Keys: 1-7 scene, Left/Right or Space next/prev, D demo, M MIDI monitor, F fullscreen, H panel, S frame stats.
- MIDI scene switch: any note on the "scene change" channel (default 16) selects scene by note number mod 7; CC 119 (any channel) selects scene by value range. Both are configurable, 0 disables.
- CCs use the real OP-XY map on each track's channel: CC7 volume (ring size), CC9 mute (dims the track to 40%; any note on that track clears the mute, since a track sending notes is playing), CC10 pan (grain position), CC12-15 engine knobs M1 E1-E4 (SCOPE shape for the active track), CC23 amp release (decay length), CC32 filter cutoff (line weight, grain size), CC33 resonance, CC38 send FX I (grain spread). Any channel: CC80 tempo (value x2 BPM, shown on the BPM readout), CC85 scene (optional "follow" toggle).
- Important: per the community docs, the OP-XY does not transmit its encoder moves as CCs in normal mode; it sends notes, clock and transport. CCs reach the visuals when the OP-XY is in MIDI controller mode (COM > M2, sending on one chosen channel) or from other gear and DAWs. Note and clock reactions do not depend on this.
- Drum tracks play notes 53-76 (the 24 keys), so the drum track is excluded from CHORD (setting in the panel).

## Scenes
1. RINGS: 16 concentric rings, one per track, flash with velocity; note dot placed by pitch class; clock hand.
2. GRID: 8 tracks x 16 steps, lit at the current clock step.
3. PULSE: clock-synced circles every beat, squares every 16th, big BPM readout.
4. CHORD: pitch-class circle, polygon of held notes plus chord name (drum track ignored).
5. GRAINS: particle bursts per note, colour by track, size by velocity.
6. SCOPE (bonus): Lissajous figure shaped by the active track's engine knobs (CC12-15), rippling with note energy.
7. ROLL (bonus): clock-synced scrolling piano roll per track colour, great for keys and guitar parts and for checking chord voicings.

## Fix log (v30 hardware fix)
- Bug: on real hardware notes reached the monitor but scenes barely reacted. Cause: a nonzero CC9 (track mute) from the device latched the track as muted and the scenes multiplied every flash by 0.15, so rings, grains and bars were near invisible. Demo mode never sends CC9, so it looked fine.
- Fix: a note on now clears the mute, mute dims to 40% instead of 15%, RINGS rings also brighten in track colour on each note, notes on unmapped channels fall back to track N, the parser handles running status and multi-message packets on the same path as the monitor, and a draw error is logged to the monitor instead of stopping a frame.
- Test: `test_midi_inject.py` (Playwright) fakes a Web MIDI input and sends raw bytes with hardware-style timestamps: clock at 110 BPM, CC9 = 127 on channels 1-5, running-status chords and CCs. Screenshots `shots/v30fix-*.png`, before fix `shots/v30-before-fix-rings-muted.png`.

- fix1: parser now handles each Chrome event (one message) on its own exactly like the original parser; running status only applies to events that start with a data byte; clock bytes never touch it. Any other message (aftertouch, program change, SysEx) is shown in the monitor as RAW hex so you can see everything the device sends. Test: `test_chrome_delivery.py` (one message per event, 24 ppqn clock interleaved, START/STOP/CONTINUE).

## Testing
Headless Chrome via Playwright in demo mode, plus raw MIDI bytes injected through `MIDI.parse()` (scene change by CC119, Cm7 chord detection). Screenshots in `shots/`.

## Performance
Rendering uses devicePixelRatio (capped at 2) with resize-only canvas reallocation, no shadow blur, capped particle counts. Headless Chrome at 1280x720, DPR 2: CPU draw time about 0.06 to 0.22 ms per frame per scene and about 60 fps (54 to 61 measured in headless). Press S to see live stats.

## Sources for MIDI mapping
- TE OP-XY guide, MIDI CC reference table (CC7/9/10/46 per track channel 1-16, CC80-86 any channel, CC90 EQ): https://teenage.engineering/guides/op-xy/midi-references
- TE OP-XY guide, COM chapter (MIDI settings, active track channel, devices, controller mode, Bluetooth MIDI): https://teenage.engineering/guides/op-xy/com
- midi.guide OP-XY chart (CC12-15 track params, CC20-27 envelopes, CC28-31 voice, CC32-35 filter, CC36-39 sends, CC102 track select): https://midi.guide/d/teenage-engineering/op-xy/
- Community OP-XY manual (channel N = track N, drum notes 53-76, encoders do not send CCs outside controller mode, CC80 = 2x BPM): https://neovand.github.io/op-xy-agent/manual/com.midi-cc-reference and https://neovand.github.io/op-xy-agent/manual/com.midi-track-ccs
Community mappings are not official; verify with COM > system > monitor on your unit.

## Limitations
- Channel defaults are an assumption; verify against the TE guide and adjust the map.
- BPM is the average interval over the last 48 clock ticks (two beats at 24 ppqn) using MIDI event timestamps, shown with 0.5 BPM hysteresis. Verified 120 in demo mode.
- No audio analysis; it is MIDI driven (like OP-Z videolab, which also reacts to MIDI, not audio).
- Not tested against real OP-XY hardware or on iOS.

## Credits
Inspired by, with no code copied: OPZ.js by Nick Weiland (MIT) https://github.com/nbw/opz, Teenage Engineering videolab (MIT) https://github.com/teenageengineering/videolab, op-z-sysex by kmorrill https://github.com/kmorrill/op-z-sysex. OP-XY and OP-Z are trademarks of teenage engineering. This is an unofficial fan project.
