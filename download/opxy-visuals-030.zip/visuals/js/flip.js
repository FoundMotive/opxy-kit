// Flip-disc mode: a grid of two-sided discs (dark grey / off-white) that flip around a diagonal hinge
// (top right to bottom left). Scenes draw into a tiny offscreen canvas (one pixel per disc); the result is
// thresholded into a bitmap and each disc flips toward it. Rendering uses a pre-rendered sprite atlas of
// flip phases and only redraws discs whose phase changed, so 160x60 on a 4K canvas stays cheap.
window.MODE=localStorage.getItem('opxy.mode')||'flip';
const FLIP=(()=>{
const fc=document.getElementById('f'),fg=fc.getContext('2d',{alpha:false});
const DENS=[{id:'auto',name:'AUTO'},{id:'classic',name:'CLASSIC 40x16',c:40,r:16},{id:'dense',name:'DENSE 96x36',c:96,r:36},{id:'ultra',name:'ULTRA 160x60',c:160,r:60}];
let dens=localStorage.getItem('opxy.dens')||'auto';if(!DENS.some(d=>d.id===dens))dens='auto';
let notch=localStorage.getItem('opxy.notch')==='1';
const COL={bg:'#0a0a0b',off:[46,47,49],on:[242,241,234]};
const NPH=16;// flip phases in the atlas (0 = dark face, NPH = light face)
let cols=40,rows=16,pitch=10,ox=0,oy=0,dpr=1,CW=0,CH=0,atlas=null,cell=0;
let tgt,ph,gate,drawn,bits,fx,fxw,N=0;
const oc=document.createElement('canvas'),og=oc.getContext('2d',{willReadFrequently:true});
function layout(){dpr=Math.min(window.devicePixelRatio||1,2);CW=Math.round(innerWidth*dpr);CH=Math.round(innerHeight*dpr);fc.width=CW;fc.height=CH;
 const d=DENS.find(x=>x.id===dens);
 if(d.c){cols=d.c;rows=d.r}else{cols=40;rows=Math.max(8,Math.round(cols*CH/CW))}
 pitch=Math.floor(Math.min(CW/cols,CH/rows));if(dens==='auto'){pitch=CW/cols;rows=Math.max(1,Math.round(CH/pitch))}
 ox=Math.floor((CW-pitch*cols)/2);oy=Math.floor((CH-pitch*rows)/2);
 const n=cols*rows;N=n;tgt=new Uint8Array(n);ph=new Float32Array(n);gate=new Float64Array(n);drawn=new Int8Array(n).fill(-1);bits=new Uint8Array(n);fx=new Uint8Array(n);fxw=new Uint8Array(n);
 oc.width=cols;oc.height=rows;buildAtlas();fg.fillStyle=COL.bg;fg.fillRect(0,0,CW,CH)}
function buildAtlas(){cell=Math.max(2,Math.ceil(pitch));atlas=document.createElement('canvas');atlas.width=cell*(NPH+1);atlas.height=cell;const a=atlas.getContext('2d');
 const r=pitch*.44;// disc diameter about 88% of pitch, gap about 12%
 for(let k=0;k<=NPH;k++){const p=k/NPH,s=Math.cos(Math.PI*p),face=s>=0?COL.off:COL.on,sq=Math.max(.06,Math.abs(s));
  const cx=k*cell+cell/2,cy=cell/2;a.fillStyle=COL.bg;a.fillRect(k*cell,0,cell,cell);
  // every phase is clipped to the disc's resting circle, so nothing (rim, notch, antialias) can draw outside it
  a.save();a.beginPath();a.arc(cx,cy,r,0,Math.PI*2);a.clip();a.translate(cx,cy);a.rotate(-Math.PI/4);a.scale(1,sq);
  const shade=.72+.28*sq,cc=face.map(v=>Math.round(v*shade));
  // tilted discs read slightly cool, like the reference footage
  if(sq<.98){cc[2]=Math.min(255,cc[2]+Math.round(14*(1-sq)))}
  a.fillStyle=`rgb(${cc})`;a.beginPath();a.arc(0,0,r,0,Math.PI*2);a.fill();
  // mid-flip edge highlight: a filled crescent inside the squashed disc (no stroke, so it never outgrows the diameter)
  if(sq<.6){a.fillStyle=`rgba(225,230,235,${(.6-sq)*.8})`;a.beginPath();a.ellipse(0,0,r,r,0,0,Math.PI);a.ellipse(0,-r*.18,r*.96,r*.82,0,Math.PI,0,true);a.fill()}
  if(notch){a.fillStyle='rgba(0,0,0,.35)';const t=Math.max(.5,r*.03)/sq;a.fillRect(-r*.98,-t,r*1.96,t*2)}
  a.restore()}}
// ---------- timing: MIDI clock when live, internal tempo otherwise ----------
let idle=false,ibeat=0,lastNow=performance.now(),beat=0,bpm=120;
function clockBeat(now){const dt=Math.min(.1,(now-lastNow)/1000);lastNow=now;
 const live=S.lastTick&&now-S.lastTick<400;bpm=S.bpm||120;
 if(live){const tick=60000/bpm/24;beat=(S.clocks+Math.min(.999,Math.max(0,(now-S.lastTick)/tick)))/24;ibeat=beat}
 else{ibeat+=dt*120/60*(S.bpm&&!idle?S.bpm/120:1);beat=ibeat}return dt}
// ---------- helpers ----------
const fr=x=>x-Math.floor(x),hash=i=>fr(Math.sin(i*127.1+311.7)*43758.5453);
const env=(b,k=6)=>Math.exp(-fr(b)*k);// beat pulse, 1 on the beat, decays
function circ(c,x,y,r){c.beginPath();c.arc(x,y,Math.max(.1,r),0,Math.PI*2);c.fill()}
function ell(c,x,y,rx,ry,rot=0){c.beginPath();c.ellipse(x,y,Math.max(.1,rx),Math.max(.1,ry),rot,0,Math.PI*2);c.fill()}
function rr(c,x,y,w,h,r){c.beginPath();c.roundRect?c.roundRect(x,y,w,h,r):c.rect(x,y,w,h);c.fill()}
function text(c,s,w,h,scale=.8){c.textAlign='center';c.textBaseline='middle';let fs=h*scale;c.font=`900 ${fs}px "Arial Black","Helvetica Neue",Arial,sans-serif`;
 const m=c.measureText(s).width;if(m>w*.92){fs*=w*.92/m;c.font=`900 ${fs}px "Arial Black","Helvetica Neue",Arial,sans-serif`}c.fillText(s,w/2,h/2+fs*.04)}
const W='#fff',K='#000';
function eye(c,x,y,rw,rh,lookX,lookY,open){// flat top, curved bottom, white pupil inside a black almond
 c.save();c.beginPath();c.rect(x-rw,y-rh*open*.25,rw*2,rh*1.2);c.clip();
 c.fillStyle=W;ell(c,x,y,rw,rh*Math.max(.05,open));c.fillStyle=K;ell(c,x+lookX*rw*.45,y+lookY*rh*.35,rw*.52,rh*.62);
 c.fillStyle=W;circ(c,x+lookX*rw*.45+rw*.12,y+lookY*rh*.35-rh*.12,Math.max(.6,rw*.14));c.restore()}
// Hands are drawn as round-capped strokes (fingers, thumb) over a rounded palm, so they stay smooth when
// thresholded at any density. Unit: s = hand height from wrist to middle fingertip. Origin at the wrist.
function stroke(c,pts,wd){c.lineCap='round';c.lineJoin='round';c.lineWidth=wd;c.beginPath();c.moveTo(pts[0][0],pts[0][1]);
 for(let k=1;k<pts.length;k++)c.lineTo(pts[k][0],pts[k][1]);c.stroke()}
function hand(c,cx,cy,s,ang,spread,eyeOpen,mirror,sym){// open hand, palm facing out, fingers up
 c.save();c.translate(cx,cy);c.rotate(ang);if(mirror)c.scale(-1,1);c.fillStyle=W;c.strokeStyle=W;
 // palm: slightly wider at the knuckles, narrowing to the wrist
 c.beginPath();c.moveTo(-s*.17,0);c.bezierCurveTo(-s*.23,-s*.12,-s*.27,-s*.3,-s*.25,-s*.43);c.lineTo(s*.25,-s*.45);
 c.bezierCurveTo(s*.27,-s*.3,s*.22,-s*.1,s*.16,0);c.closePath();c.fill();rr(c,-s*.17,-s*.02,s*.33,s*.2,s*.05);
 // fingers: [base x, length, width, base y], fanned by spread
 const F=[[-.2,.38,.095,-.42],[-.068,.44,.1,-.45],[.068,.42,.095,-.45],[.2,.32,.085,-.42]];
 F.forEach(([x,l,wd,y],k)=>{const a=(k-1.5)*spread,bx=x*s,by=y*s;stroke(c,[[bx,by+s*.05],[bx+Math.sin(a)*l*s,by-Math.cos(a)*l*s]],wd*s)});
 // thumb: two segments angled out from the lower palm
 const ta=-.75-spread*.8;const t0=[-s*.2,-s*.12],t1=[t0[0]+Math.sin(ta)*s*.17,t0[1]-Math.cos(ta)*s*.17],t2=[t1[0]+Math.sin(ta+.35)*s*.16,t1[1]-Math.cos(ta+.35)*s*.16];
 stroke(c,[t0,t1,t2],s*.115);if(sym){c.save();c.scale(-1,1);stroke(c,[t0,t1,t2],s*.11);c.restore()}
 if(eyeOpen!=null){c.fillStyle=K;ell(c,0,-s*.24,s*.14,s*.075*Math.max(.12,eyeOpen));c.fillStyle=W;circ(c,0,-s*.24,s*.04*Math.max(.25,eyeOpen))}
 c.restore()}
function pointHand(c,cx,cy,s){// fist pointing right with index extended; origin at the wrist; s = hand length
 c.save();c.translate(cx,cy);c.fillStyle=W;c.strokeStyle=W;
 rr(c,0,-s*.2,s*.42,s*.4,s*.14);// back of the hand
 stroke(c,[[s*.3,-s*.12],[s*.86,-s*.12]],s*.12);// index finger
 for(let k=0;k<3;k++)stroke(c,[[s*.32,s*.0+k*s*.1],[s*.47,s*.0+k*s*.1]],s*.095);// curled fingers
 stroke(c,[[s*.12,-s*.18],[s*.3,-s*.3],[s*.42,-s*.28]],s*.1);// thumb resting on top
 rr(c,-s*.5,-s*.16,s*.52,s*.32,s*.03);// sleeve
 c.restore()}
// ---------- scenes: draw(c,w,h,b,X) with c sized w x h (one pixel per disc), white = light face ----------
const ALL=[
{n:'DOT',d(c,w,h,b){c.fillStyle=W;const on=fr(b)<.5||fr(b/4)<.75;if(on)circ(c,w/2,h/2,Math.max(.6,Math.min(w,h)*.04*(1+env(b)*1.5)))}},
{n:'BLINK',d(c,w,h,b){const i=Math.floor(b*2),x=hash(i)*w,y=hash(i+9)*h;c.fillStyle=W;if(fr(b*2)<.5)circ(c,Math.floor(x)+.5,Math.floor(y)+.5,.7+Math.min(w,h)*.02)}},
{n:'RISE',d(c,w,h,b){c.fillStyle=W;const n=Math.max(3,Math.round(w/10));for(let i=0;i<n;i++){const x=Math.round((i+.5)*w/n),p=fr(b/2+hash(i)*.5);const len=h*ease(Math.min(1,p*2));c.fillRect(x,h-len,Math.max(1,w/80),len*(p<.5?1:1-((p-.5)*2)))}}},
{n:'ARROW',off:1,d(c,w,h,b){const p=fr(b/4),u=h*.5,x=(p*1.4-.2)*w;c.fillStyle=W;const t=Math.max(1,h*.07),m=Math.min(1,fr(b/4)*4);
 c.fillRect(x-u*1.5,h/2-t/2,u*1.5,t);if(m>.3){c.beginPath();c.moveTo(x+u*.5*m,h/2);c.lineTo(x-u*.2,h/2-u*.5*m);c.lineTo(x-u*.2,h/2+u*.5*m);c.fill()}}},
{n:'STATIC',d(c,w,h,b,X){const seed=Math.floor(b*4),dens=.25+.5*X.energy+.15*env(b);c.fillStyle=W;for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(hash(x*7.1+y*131.7+seed*17.3)<dens*(.6+.4*Math.sin(y/h*6+b)))c.fillRect(x,y,1,1)}},
{n:'DUST',d(c,w,h,b){c.fillStyle=W;const n=Math.round(w*h*.04);for(let i=0;i<n;i++){const sp=.05+hash(i)*.15,x=fr(hash(i+1)+b*sp)*w,y=(hash(i+2)*h+Math.sin(b*.5+i)*1.2+h)%h;c.fillRect(Math.floor(x),Math.floor(y),1,1)}}},
{n:'BARCODE',d(c,w,h,b){const seed=Math.floor(b);c.fillStyle=W;let x=0,i=0;while(x<w){const bw=1+Math.floor(hash(seed*31+i)*4*w/40);if(i%2)c.fillRect(x,0,bw,h);x+=bw;i++}
 const g=Math.floor(fr(b)*h*3);c.globalCompositeOperation='xor';for(let k=0;k<3;k++){const y=Math.floor(hash(seed+k)*h);c.fillRect((g*(k+1))%w-w/2,y,w,Math.max(1,h/16))}c.globalCompositeOperation='source-over'}},
{n:'SKULL',off:1,d(c,w,h,b){const u=h*.9,cx=w/2,cy=h*.47;c.fillStyle=W;rr(c,cx-u*.42,cy-u*.45,u*.84,u*.62,u*.3);rr(c,cx-u*.28,cy+u*.1,u*.56,u*.32,u*.06);
 c.fillStyle=K;const f=env(b,4);ell(c,cx-u*.18,cy-u*.08,u*.13,u*.12*(1-.5*f));ell(c,cx+u*.18,cy-u*.08,u*.13,u*.12*(1-.5*f));
 c.beginPath();c.moveTo(cx,cy+u*.04);c.lineTo(cx-u*.05,cy+u*.14);c.lineTo(cx+u*.05,cy+u*.14);c.fill();
 const jaw=Math.floor(b)%2?u*.05:0;for(let i=-2;i<=2;i++)c.fillRect(cx+i*u*.1-u*.015,cy+u*.24+jaw,Math.max(1,u*.03),u*.18)}},
{n:'POINT',off:1,d(c,w,h,b){const s=Math.min(h*.95,w*.55),tap=env(b,5)*s*.08;pointHand(c,w*.5-s*.38+tap,h*.52,s)}},
{n:'WAVE HAND',off:1,d(c,w,h,b){const s=Math.min(h*1.08,w*.8);hand(c,w/2,h*.42+s*.6,s,Math.sin(b*Math.PI*.5)*.22,.13+.05*env(b),null)}},
{n:'HAMSA',off:1,d(c,w,h,b){const s=Math.min(h*1.05,w*.8),bl=fr(b/4)>.9?.12:1;hand(c,w/2,h*.45+s*.58,s,0,.07,bl,false,true)}},
{n:'EYES',d(c,w,h,b,X){const lx=X.lookX,ly=X.lookY,open=fr(b/4)>.92?.08:1,r=Math.min(w*.2,h*.35);eye(c,w*.3,h*.42,r,r*.7,lx,ly,open);eye(c,w*.7,h*.42,r,r*.7,lx,ly,open)}},
{n:'GIANT EYE',d(c,w,h,b,X){c.fillStyle=W;c.fillRect(0,0,w,h);const open=fr(b/4)>.9?.05:1;c.fillStyle=K;
 const cx=w/2+X.lookX*w*.12,cy=h*.5+X.lookY*h*.08,R=h*(.42+.04*env(b));circ(c,cx,cy,R);c.fillStyle=W;circ(c,cx,cy,R*(.35+.15*X.energy));c.fillStyle=K;circ(c,cx,cy,R*.22);c.fillStyle=W;circ(c,cx+R*.3,cy-R*.3,R*.12);
 c.fillStyle=K;const lid=(1-open)*h*.5;c.fillRect(0,0,w,lid);c.fillRect(0,h-lid,w,lid)}},
{n:'PLANET',d(c,w,h,b){const cx=w/2,cy=h/2,R=h*.3,t=-.35+Math.sin(b*.25)*.1;c.fillStyle=W;circ(c,cx,cy,R);c.strokeStyle=W;c.lineWidth=Math.max(1,h*.05);
 c.beginPath();c.ellipse(cx,cy,R*2.1,R*.55,t,Math.PI*.98,Math.PI*2.02);c.stroke();c.fillStyle=K;c.beginPath();c.ellipse(cx,cy,R*2.1+c.lineWidth,R*.55+c.lineWidth,t,0,Math.PI);c.lineTo(cx,cy);c.fill();
 c.strokeStyle=W;c.beginPath();c.ellipse(cx,cy,R*2.1,R*.55,t,0,Math.PI);c.stroke();
 for(let i=0;i<6;i++){const a=b*.5*Math.PI+i*1.05;c.fillStyle=W;circ(c,cx+Math.cos(a)*R*2.6*Math.cos(t)-Math.sin(a)*R*.7*Math.sin(t),cy+Math.cos(a)*R*2.6*Math.sin(t)+Math.sin(a)*R*.7*Math.cos(t),.6)}}},
{n:'COLLIDE',d(c,w,h,b){const p=fr(b/4),s=h*.45;let x=p<.75?ease(p/.75)*(w/2-s):w/2-s;c.fillStyle=W;c.fillRect(x,h/2-s/2,s,s);c.fillRect(w-x-s,h/2-s/2,s,s);
 if(p>=.75){const q=(p-.75)/.25;for(let i=0;i<24;i++){const a=hash(i+Math.floor(b/4))*6.28,d=q*w*.4*hash(i+3);c.fillRect(w/2+Math.cos(a)*d,h/2+Math.sin(a)*d,1,1)}}}},
{n:'BPM',d(c,w,h,b,X){c.fillStyle=W;text(c,X.bpmText,w,h,.75);if(fr(b)<.12){c.globalCompositeOperation='xor';c.fillRect(0,0,w,Math.max(1,h*.06));c.globalCompositeOperation='source-over'}}},
{n:'NOTE',off:1,d(c,w,h,b,X){c.fillStyle=W;text(c,X.note,w,h,.8)}},
{n:'CHORD',d(c,w,h,b,X){// held pitch classes as a polygon on a circle, never as text
 const cx=w/2,cy=h/2,R=Math.min(w,h)*.42,rot=b*.08,pc=X.pcs.length>=2?X.pcs:[0,4,7],P=i=>[cx+Math.sin(i/12*Math.PI*2+rot)*R,cy-Math.cos(i/12*Math.PI*2+rot)*R];
 c.fillStyle=W;for(let i=0;i<12;i++){const[x,y]=P(i);circ(c,x,y,Math.max(.5,R*.05))}
 c.beginPath();pc.forEach((i,k)=>{const[x,y]=P(i);k?c.lineTo(x,y):c.moveTo(x,y)});c.closePath();c.globalAlpha=.6+.4*env(b);c.fill();c.globalAlpha=1;
 pc.forEach(i=>{const[x,y]=P(i);circ(c,x,y,Math.max(.8,R*(.1+.05*env(b))))})}},
{n:'COUNT',d(c,w,h,b){c.fillStyle=W;const bar=Math.floor(b/4)%100,st=Math.floor(b*4)%16;text(c,String(bar).padStart(2,'0').split('').join(' ')+' '+String(st+1).padStart(2,'0'),w,h,.7)}},
{n:'RIPPLE',d(c,w,h,b){c.strokeStyle=W;c.lineWidth=Math.max(1,h*.05);for(let k=0;k<3;k++){const p=fr(b/2+k/3);c.globalAlpha=1;c.beginPath();c.arc(w/2,h/2,p*w*.6,0,6.3);c.stroke()}}},
{n:'HEART',off:1,d(c,w,h,b){const k=1+.18*env(b,5)+.1*env(b-.25,7),s=h*.38*k,cx=w/2,cy=h*.52;c.fillStyle=W;c.beginPath();c.moveTo(cx,cy+s);
 c.bezierCurveTo(cx-s*1.6,cy,cx-s*.9,cy-s*1.15,cx,cy-s*.4);c.bezierCurveTo(cx+s*.9,cy-s*1.15,cx+s*1.6,cy,cx,cy+s);c.fill()}},
{n:'ECG',d(c,w,h,b){c.strokeStyle=W;c.lineWidth=Math.max(1,h*.06);c.beginPath();for(let x=0;x<=w;x++){const bb=b-(w-x)/w*2,f=fr(bb);let y=h/2;
 if(f<.06)y-=h*.38*Math.sin(f/.06*Math.PI);else if(f<.1)y+=h*.15*Math.sin((f-.06)/.04*Math.PI);x?c.lineTo(x,y):c.moveTo(x,y)}c.stroke()}},
{n:'RAIN',d(c,w,h,b){c.fillStyle=W;const n=Math.round(w*.6);for(let i=0;i<n;i++){const x=Math.floor(hash(i)*w),sp=1+hash(i+5),y=fr(hash(i+7)+b*sp*.5)*(h+6)-3;c.fillRect(x,Math.floor(y),1,Math.max(2,h/12))}
 const sp=Math.floor(b);c.fillRect(0,h-1,w,1);for(let i=0;i<4;i++){const x=hash(sp*9+i)*w;if(fr(b)<.4)c.fillRect(x-fr(b)*6,h-2,fr(b)*12,1)}}},
{n:'SEQUENCER',d(c,w,h,b,X){const st=Math.floor(b*4)%16,cw=w/16;for(let i=0;i<16;i++){c.fillStyle=W;const x=Math.floor(i*cw)+1,ww=Math.max(1,Math.floor(cw)-2);
 if(i===st)c.fillRect(x,h*.15,ww,h*.7);else{c.fillRect(x,h*.78,ww,Math.max(1,h*.07));const v=X.grid[i];if(v)c.fillRect(x,h*(.78-v*.55),ww,h*v*.55-1)}}}},
{n:'WAVES',d(c,w,h,b,X){c.fillStyle=W;for(let x=0;x<w;x++){const y=h/2+Math.sin(x/w*Math.PI*4+b*Math.PI)*h*.22*(1+X.energy)+Math.sin(x/w*11-b*2)*h*.06;c.fillRect(x,y,1,h-y)}}},
{n:'SPIRAL',d(c,w,h,b){c.fillStyle=W;const cx=w/2,cy=h/2,R=Math.hypot(w,h)/2;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const dx=x+.5-cx,dy=(y+.5-cy),a=Math.atan2(dy,dx),r=Math.hypot(dx,dy)/R;
 if(fr(a/Math.PI*1.5+r*3-b*.5)<.42)c.fillRect(x,y,1,1)}}},
{n:'MAZE',d(c,w,h,b){c.strokeStyle=W;c.lineWidth=1;const seed=Math.floor(b/4),s=Math.max(2,Math.round(h/8)),rev=fr(b/4)*1.3;c.beginPath();
 for(let y=0;y<h;y+=s)for(let x=0;x<w;x+=s){if((x+y)/(w+h)>rev)continue;if(hash(x*3+y*7+seed)<.5){c.moveTo(x,y);c.lineTo(x+s,y+s)}else{c.moveTo(x+s,y);c.lineTo(x,y+s)}}c.stroke()}},
{n:'CHECKER',d(c,w,h,b){c.fillStyle=W;const s=Math.max(1,Math.round(h/8)),o=Math.floor(b)%2;for(let y=0;y<h;y+=s)for(let x=0;x<w;x+=s)if(((x/s+y/s)|0)%2===o)c.fillRect(x,y,s,s)}},
{n:'ECLIPSE',d(c,w,h,b){c.fillStyle=W;c.fillRect(0,0,w,h);c.fillStyle=K;const R=h*.4;circ(c,w/2,h/2,R);c.fillStyle=W;const p=fr(b/8);circ(c,w/2+(p*2-1)*R*2.2,h/2-R*.1,R*.95)}},
{n:'FACE',off:1,d(c,w,h,b){const u=h*.85,cx=w/2,cy=h/2;c.fillStyle=W;rr(c,cx-u*.5,cy-u*.5,u,u,u*.12);c.fillStyle=K;const o=fr(b/4)>.88?.15:1;
 c.fillRect(cx-u*.3,cy-u*.2,u*.18,u*.2*o);c.fillRect(cx+u*.12,cy-u*.2,u*.18,u*.2*o);const m=env(b,5);c.fillRect(cx-u*.25,cy+u*.15,u*.5,Math.max(1,u*(.06+.14*m)))}},
];
const SC=ALL.filter(s=>!s.off);// SKULL, ARROW, NOTE stay in code but out of rotation
function ease(t){return t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2}
// ---------- transitions: per-disc delay maps in 0..1, scaled to one beat ----------
const WIPES=[
 (x,y)=>(x/cols+y/rows)/2,
 (x,y)=>(1-x/cols+y/rows)/2,
 (x,y)=>(x%2?.5:0)+x/cols*.5,
 (x,y)=>hash(x*13+y*71),
 (x,y)=>Math.hypot(x-cols/2,(y-rows/2))/Math.hypot(cols/2,rows/2),
 (x,y)=>y/rows*.6+hash(x)*.4,
 (x,y)=>((x+y)%2?.5:0)+hash(x+y*5)*.3];
let cur=0,lastChange=-99,pending=null,wipeN=0;
function setFlip(i,wipe,now){if(window.__flipStat){__flipStat.changes.push(+beat.toFixed(2));__flipStat.scenes&&__flipStat.scenes.push(SC[((i%SC.length)+SC.length)%SC.length].n)}cur=((i%SC.length)+SC.length)%SC.length;lastChange=beat;const f=WIPES[wipe==null?(wipeN++%WIPES.length):wipe],dur=60000/bpm*.9;
 for(let y=0;y<rows;y++)for(let x=0;x<cols;x++)gate[y*cols+x]=now+f(x,y)*dur;
 if(window.MODE==='flip')$('scene').textContent=String(cur+1).padStart(2,'0')+' '+SC[cur].n;window.__flipScene=SC[cur].n}
// ---------- MIDI reactions ----------
const ripples=[],X={energy:0,lookX:.4,lookY:.4,pcs:[],bpmText:'120',grid:Array(16).fill(0)};
// Tracks 1 and 2 (the drums) lead: they drive ripples, pulses and scene picks. Tracks 3-8 only add spice now
// and then (a weighted chance per bar, higher when drums are quiet), with notes collapsed and pops capped.
const STAT={notes:0,drumNotes:0,drumR:0,pops:0,kinds:{},lat:[],changes:[],scenes:[],idle:[]};window.__flipStat=STAT;
const recent={},isDrum=t=>t<=1||t===cfg.drumTrack-1;
let lastNoteBeat=-99,hold=/hold/.test(location.hash),lastDrumMs=0,lastOtherMs=0,popsBeat=-1,popsN=0,ripBeat=-1,ripN=0;
const lastKind={},fxq=[];let barDrums=0,prevBarDrums=0,spiceBar=-1,spice=false,drumScore=0;
// idle: before playback (no START, no notes) or a few seconds after STOP, only the plain wall with a breathing centre
const IDLE_MS=4000;let lastAnyNote=-1e9,lastStop=-1e9,forced=/flip=|hold/.test(location.hash);
MIDI.on(e=>{if(e.type==='stop'){forced=false;lastStop=performance.now()}if(e.type==='noteon')lastAnyNote=performance.now();});
function drawIdle(c,w,h,b){const p=env(b,4),r=Math.max(.75,Math.min(w,h)*(.045+.03*p));c.fillStyle=W;c.beginPath();c.arc(w/2,h/2,r,0,7);c.fill()}
MIDI.on(e=>{if(e.type!=='noteon')return;if(cfg.sceneCh&&e.ch===cfg.sceneCh)return;
 const t=noteTrack(e.ch);if(t<0||t>15)return;const v=e.vel/127,drum=isDrum(t);STAT.notes++;if(drum)STAT.drumNotes++,tn=performance.now(),bi=Math.floor(beat);lastNoteBeat=beat;
 if(drum){barDrums++;drumScore=(drumScore*7+e.note+t*13)%997;
  const kind=e.note<55?'kick':e.note<58?'snare':'hat';if(tn-(lastKind[kind]||-1e9)<30)return;lastKind[kind]=tn;// only hits within 30 ms merge
  X.energy=Math.min(1,X.energy+v*.25);X.grid[Math.floor(beat*4)%16]=Math.max(X.grid[Math.floor(beat*4)%16],.4+v*.6);
  STAT.drumR++;STAT.kinds[kind]=(STAT.kinds[kind]||0)+1;fxq.push({kind,t0:tn,v,x:kind==='kick'?cols/2:cols*(.2+.6*hash(e.note*7+STAT.drumR)),y:kind==='kick'?rows/2:rows*(.15+.7*hash(STAT.drumR*3.1)),id:STAT.drumR});if(fxq.length>8)fxq.shift();
  return}
 // other tracks: chords are detected per channel even when spice is off, so CHORD can show the shape
 const rc=(recent[e.ch]=(recent[e.ch]||[]).filter(x=>tn-x<80));rc.push(tn);
 if(rc.length>=2)X.pcs=[...new Set([...S.held.values()].map(h=>h.pc))].sort((a,b)=>a-b);
 if(!spice)return;if(tn-lastOtherMs<120)return;lastOtherMs=tn;// collapse simultaneous notes into one reaction
 if(popsBeat!==bi){popsBeat=bi;popsN=0}if(popsN>=2)return;popsN++;
 X.lookX=(e.note%12)/5.5-1;X.lookY=v*1.2-.4;
 STAT.pops++;fxq.push({kind:'pop',t0:tn,v,x:((e.note-24)%48+48)%48/48*cols,y:rows*(.2+.6*hash(e.note)),id:STAT.pops});if(fxq.length>8)fxq.shift();
 if(rc.length===3&&X.pcs.length>=3&&pending==null)pending=SC.findIndex(s=>s.n==='CHORD')});
function onBar(bar){// decide spice for this bar, then reset the drum count
 prevBarDrums=barDrums;barDrums=0;const quiet=prevBarDrums<2;spice=hash(bar*3.7)<(quiet?.6:.35);spiceBar=bar}
// ---------- frame ----------
const MIN_GAP=8;let lastBeatInt=-1,ft=[],fps=0,frames=[];
function frame(now){requestAnimationFrame(frame);if(window.MODE!=='flip')return;const t0=performance.now(),dt=clockBeat(now);
 const tnow=performance.now(),act=forced||S.playing||(lastAnyNote>lastStop&&tnow-lastAnyNote<IDLE_MS);if(act===idle){idle=!act;if(window.__flipStat)__flipStat.idle.push([+(now/1000).toFixed(2),idle]);
  if(idle){ripples.length=0;fxq.length=0;pending=null;for(let i=0;i<N;i++)gate[i]=tnow+hash(i)*120;$('scene').textContent='IDLE';window.__flipScene='IDLE'}else{lastBeatInt=Math.floor(beat);setFlip(cur+1,null,now)}}
 const bi=Math.floor(beat);X.energy*=Math.pow(.2,dt);X.bpmText=String(Math.round(S.bpm||120));if(bi!==lastBeatInt){X.grid[(Math.floor(beat*4)+1)%16]*=.5}
 if(bi<lastChange-1)lastChange=bi-4;
 if(idle)lastBeatInt=bi;
 if(bi!==lastBeatInt&&hold)lastBeatInt=bi;
 if(bi!==lastBeatInt){// scene changes land on bar starts only, at least 2 bars (8 beats) apart
  if(bi%4===0){onBar(bi/4);
   if(bi-lastChange>=(prevBarDrums>=8?4:MIN_GAP)-.5){const nx=pending!=null&&pending!==cur?pending:(cur+1+(drumScore+Math.floor(hash(bi)*5))%5)%SC.length;setFlip(nx,null,now);pending=null}}
  lastBeatInt=bi}
 og.setTransform(1,0,0,1,0,0);og.globalCompositeOperation='source-over';og.globalAlpha=1;og.fillStyle=K;og.fillRect(0,0,cols,rows);
 try{og.save();if(idle)drawIdle(og,cols,rows,beat);else SC[cur].d(og,cols,rows,Math.floor(beat*4)/4,X);og.restore()}catch(err){log('flip draw error: '+err.message)}
 const id=og.getImageData(0,0,cols,rows).data;for(let i=0;i<N;i++)bits[i]=id[i*4]>127?1:0;
 // beat grid accents: a border flash on each beat, thicker on bar 1
 fx.fill(0);const inv=i=>{bits[i]^=1;fx[i]=1};
 if(!idle){const fb=fr(beat);if(fb<.12){const bar1=Math.floor(beat)%4===0,th=bar1?Math.max(2,Math.round(rows*.08)):1;
  for(let y=0;y<rows;y++)for(let x=0;x<cols;x++)if(x<th||y<th||x>=cols-th||y>=rows-th)inv(y*cols+x)}}
 // drum and pop reactions, timed in ms so they show on the first frame after the note; size by velocity
 for(let k=fxq.length-1;k>=0;k--){const r=fxq[k],ms=tnow-r.t0,v=r.v;
  const life=r.kind==='kick'?260+v*220:r.kind==='snare'?140+v*120:r.kind==='hat'?90:180;if(ms>life){fxq.splice(k,1);continue}const a=Math.max(0,ms/life);
  if(r.kind==='kick'){// punch: a filled disc that opens into a ring
   const R0=1.2+v*Math.min(cols,rows)*.12,R=R0+a*Math.max(cols,rows)*(.25+.35*v),th=ms<70?R:.6+v*.9;
   for(let y=Math.max(0,Math.floor(r.y-R-1));y<=Math.min(rows-1,Math.ceil(r.y+R+1));y++)for(let x=Math.max(0,Math.floor(r.x-R-1));x<=Math.min(cols-1,Math.ceil(r.x+R+1));x++){const d=Math.hypot(x+.5-r.x,y+.5-r.y);if(d<=R&&d>=R-th)inv(y*cols+x)}}
  else if(r.kind==='snare'){// invert a band across the wall that thins out
   const hh=Math.max(1,(1+v*rows*.2)*(1-a)),y0=Math.max(0,Math.round(r.y-hh/2)),y1=Math.min(rows,Math.round(r.y+hh/2)+1);
   for(let y=y0;y<y1;y++)for(let x=0;x<cols;x++)inv(y*cols+x)}
  else if(r.kind==='hat'){// a scatter of single discs
   const n=Math.round(2+v*N*.012);for(let q=0;q<n;q++)inv(Math.floor(hash(r.id*31+q*7.3)*N)%N)}
  else{const R=.8+v*1.2+a*2;for(let y=Math.max(0,Math.floor(r.y-R));y<=Math.min(rows-1,Math.ceil(r.y+R));y++)for(let x=Math.max(0,Math.floor(r.x-R));x<=Math.min(cols-1,Math.ceil(r.x+R));x++){const d=Math.hypot(x+.5-r.x,y+.5-r.y);if(ms<60?d<=R:Math.abs(d-R)<.6)inv(y*cols+x)}}
  if(!r.seen){r.seen=1;STAT.lat.push(+(tnow-r.t0).toFixed(1))}}
 if(STAT.lat.length>400)STAT.lat.splice(0,200);
 const step=dt*1000/130;// one flip takes about 130 ms, a few frames like the footage
 const sx=cell;for(let i=0;i<N;i++){if(bits[i]!==tgt[i]&&(fx[i]||now>=gate[i]))tgt[i]=bits[i];const g=tgt[i];let p=ph[i];
  if(p!==g){const st=fx[i]||fxw[i]?Math.max(step*3,.34):step;p=g?Math.min(1,p+st):Math.max(0,p-st);ph[i]=p;fxw[i]=p!==g?fxw[i]|fx[i]:0}const k=Math.round(p*NPH);
  if(k!==drawn[i]){drawn[i]=k;const x=i%cols,y=(i/cols)|0;fg.drawImage(atlas,k*sx,0,sx,sx,Math.round(ox+x*pitch+(pitch-sx)/2),Math.round(oy+y*pitch+(pitch-sx)/2),sx,sx)}}
 ft.push(performance.now()-t0);if(ft.length>240)ft.shift();frames.push(now);while(frames[0]<now-1000)frames.shift();fps=frames.length;
 if(showStats&&(now|0)%10<17)$('stats').textContent=`flip ${cols}x${rows} draw ${(ft.reduce((a,b)=>a+b,0)/ft.length).toFixed(2)} ms / fps ${fps}`}
function setMode(m){window.MODE=m;localStorage.setItem('opxy.mode',m);fc.classList.toggle('hidden',m!=='flip');if(m==='flip'){drawn.fill(-1);fg.fillStyle=COL.bg;fg.fillRect(0,0,CW,CH);setFlip(cur,3,performance.now())}else setScene(scene)}
function setDens(d){dens=d;localStorage.setItem('opxy.dens',d);layout();setFlip(cur,3,performance.now());const s=$('density');if(s)s.value=d}
addEventListener('resize',()=>{layout();setFlip(cur,3,performance.now())});
layout();
const sel=$('density');if(sel){sel.innerHTML=DENS.map(d=>`<option value="${d.id}">${d.name}</option>`).join('');sel.value=dens;sel.onchange=()=>setDens(sel.value)}
$('notch')&&($('notch').checked=notch,$('notch').onchange=()=>{notch=$('notch').checked;localStorage.setItem('opxy.notch',notch?'1':'0');buildAtlas();drawn.fill(-1)});
function atlasCheck(){// test hook: count atlas pixels that differ from the background outside each disc circle
 const a=atlas.getContext('2d'),d=a.getImageData(0,0,atlas.width,cell).data,r=pitch*.44,bg=[10,10,11];let bad=0,worst=0;
 for(let k=0;k<=NPH;k++)for(let y=0;y<cell;y++)for(let x=0;x<cell;x++){if(Math.hypot(x+.5-cell/2,y+.5-cell/2)<=r+1)continue;
  const i=(y*atlas.width+k*cell+x)*4,df=Math.max(Math.abs(d[i]-bg[0]),Math.abs(d[i+1]-bg[1]),Math.abs(d[i+2]-bg[2]));if(df>2)bad++;worst=Math.max(worst,df)}
 return{bad,worst,cell,phases:NPH+1}}
const api={SC,atlasCheck,atlasURL:()=>atlas.toDataURL(),set hold(v){hold=v},setFlip:i=>{forced=true;setFlip(i,3,performance.now())},get idle(){return idle},setDens,setMode,key(k,e){
 if(k==='arrowright'||k===' '){e.preventDefault();forced=true;setFlip(cur+1,null,performance.now());return true}
 if(k==='arrowleft'){forced=true;setFlip(cur-1,null,performance.now());return true}
 if(k==='g'){const i=DENS.findIndex(d=>d.id===dens);setDens(DENS[(i+1)%DENS.length].id);return true}
 if(k==='v'){setMode('classic');return true}return false},
 perf:()=>({avgDraw:ft.reduce((a,b)=>a+b,0)/ft.length,maxDraw:Math.max(...ft),fps,cols,rows,canvas:CW+'x'+CH}),get cur(){return cur},get beat(){return beat}};
setMode(window.MODE);
const m2=location.hash.match(/flip=(\d+)/);if(m2)setFlip(+m2[1]-1,3,performance.now());
const m3=location.hash.match(/dens=(\w+)/);if(m3)setDens(m3[1]);
if(/(^#|,|&)classic($|,|&)/.test(location.hash))setMode('classic');
requestAnimationFrame(frame);
return api})();
// classic mode: V switches back to flip discs
addEventListener('keydown',e=>{if(window.MODE!=='flip'&&e.key.toLowerCase()==='v'&&e.target.tagName!=='INPUT')FLIP.setMode('flip')});
