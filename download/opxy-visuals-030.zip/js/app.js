const cv=document.getElementById('c'),g=cv.getContext('2d',{alpha:false}),$=id=>document.getElementById(id);
// OP-XY default: channel N addresses track N (1-8 instrument tracks, 9-16 auxiliary tracks). See README sources.
const DEF=[...Array(16)].map((_,i)=>i+1);
let chmap=JSON.parse(localStorage.getItem('opxy.chmap')||'null')||DEF.slice();
const cfg=Object.assign({sceneCh:16,sceneCC:119,followScene:false,drumTrack:1},JSON.parse(localStorage.getItem('opxy.cfg')||'{}'));
const saveCfg=()=>localStorage.setItem('opxy.cfg',JSON.stringify(cfg));
// Real OP-XY CC map (per-track channel): 7 vol, 9 mute, 10 pan, 12-15 engine params (M1 E1-E4),
// 20-23 amp ADSR, 24-27 filter ADSR, 32 cutoff, 33 resonance, 34 env amt, 38/39 send FX I/II. Any channel: 80 tempo, 85 scene.
const CC={7:'vol',9:'mute',10:'pan',12:'p0',13:'p1',14:'p2',15:'p3',23:'rel',32:'cut',33:'res',38:'fx1',39:'fx2'};
const mkT=()=>({env:0,envS:0,vel:0,last:-1,vol:1,mute:0,pan:.5,p:[.3,.45,.2,.3],rel:.4,cut:.6,res:.2,fx1:0,fx2:0});
const S={tracks:[...Array(16)].map(mkT),held:new Map(),pcs:Array(12).fill(0),pcsS:Array(12).fill(0),grid:[...Array(8)].map(()=>Array(16).fill(0)),
 pulses:[],parts:[],clocks:0,step:0,stepS:0,phase:0,phaseS:0,beatPos:0,beatEnv:0,bpm:0,bpmShow:'---',ticks:[],lastTick:0,playing:false,energy:0,energyS:0,lastTrack:0,
 chordPoly:[],chordName:'',chordA:0,chordTrack:2,chordHist:[],roll:[],rollLo:36,rollHi:84};
let scene=+(localStorage.getItem('opxy.scene')||0),demo=false;
const trackOf=ch=>chmap.indexOf(ch);
// notes on a channel missing from the map still drive the scenes (channel N falls back to track N)
const noteTrack=ch=>{const t=trackOf(ch);return t>=0?t:ch-1};
function setScene(i){scene=((i%SCENES.length)+SCENES.length)%SCENES.length;localStorage.setItem('opxy.scene',scene);$('scene').textContent=String(scene+1).padStart(2,'0')+' '+SCENES[scene].name}
let logBuf=[];function log(s){logBuf.unshift(s);logBuf.length=Math.min(logBuf.length,60);if(!$('monitor').classList.contains('hidden'))$('monitor').textContent=logBuf.join('\n')}
const fmt=e=>{const t=trackOf(e.ch);const tn=t>=0?TRACK_LABEL[t]:'--';
 if(e.type==='noteon')return `ch${String(e.ch).padStart(2)} ${tn.padEnd(3)} NOTE ON  ${NAMES[e.note%12]}${Math.floor(e.note/12)-1} (${e.note}) vel ${e.vel}`;
 if(e.type==='noteoff')return `ch${String(e.ch).padStart(2)} ${tn.padEnd(3)} NOTE OFF ${e.note}`;
 if(e.type==='cc')return `ch${String(e.ch).padStart(2)} ${tn.padEnd(3)} CC ${e.cc} = ${e.val}${CC[e.cc]?' ('+CC[e.cc]+')':''}`;if(e.type==='raw')return 'RAW '+e.bytes.map(b=>b.toString(16).toUpperCase().padStart(2,'0')).join(' ');return e.type.toUpperCase()+(e.val!=null?' '+e.val:'')};
// BPM: average interval across the last 48 clock ticks (two beats at 24 ppqn), shown with 0.5 BPM hysteresis.
function clockBpm(ts){S.ticks.push(ts);if(S.ticks.length>49)S.ticks.shift();const n=S.ticks.length-1;if(n<12)return;
 const d=(S.ticks[n]-S.ticks[0])/n;if(d<=0)return;const b=60000/(d*24);if(b<20||b>400)return;S.bpm=b;
 const r=Math.round(b*2)/2;if(S.bpmShow==='---'||Math.abs(r-parseFloat(S.bpmShow))>=.5)S.bpmShow=(Math.abs(r-Math.round(r))<.01?Math.round(r):r.toFixed(1))+''}
MIDI.on(e=>{if(e.type!=='clock')log(fmt(e));
 switch(e.type){
 case 'clock':{if(S.lastTick&&e.ts-S.lastTick>400)S.ticks=[];S.lastTick=e.ts;clockBpm(e.ts);S.clocks++;S.phase=S.clocks/24;
  if(S.clocks%6===0){S.step++;S.pulses.push({age:0,beat:S.clocks%24===0,bar:S.clocks%96===0,c:S.clocks%96===0?'#ff6a00':'#fff'})}
  if(S.clocks%24===0)S.beatEnv=1;$('bpm').textContent=S.bpmShow+' BPM';break}
 case 'start':S.clocks=0;S.step=0;S.ticks=[];S.playing=true;S.beatEnv=1;$('play').textContent='PLAY';break;
 case 'continue':S.playing=true;$('play').textContent='PLAY';break;
 case 'stop':S.playing=false;$('play').textContent='STOP';S.held.clear();recalc();S.roll.forEach(n=>{if(n.b1==null)n.b1=S.beatPos});break;
 case 'noteon':{if(cfg.sceneCh&&e.ch===cfg.sceneCh){setScene(e.note);return}
  const t=noteTrack(e.ch);if(t<0||t>15)return;const T=S.tracks[t],v=e.vel/127;T.env=1;T.mute=0;// a track that sends notes is playing, so clear any stale CC9 muteT.vel=v;T.last=e.note;S.lastTrack=t;S.energy=Math.min(1,S.energy+v*.35);
  if(t!==cfg.drumTrack-1){S.held.set(e.ch+':'+e.note,{pc:e.note%12,t});recalc()}
  if(t<8)S.grid[t][S.step%16]=Math.max(S.grid[t][S.step%16],.45+v*.55);
  S.roll.push({n:e.note,t,v,ch:e.ch,b0:S.beatPos,b1:null});if(S.roll.length>600)S.roll.splice(0,S.roll.length-600);
  const N=8+Math.round(v*26),bx=.08+((e.note-24)%60)/60*.84,by=.25+(1-T.pan)*0+t/16*.6;
  for(let i=0;i<N;i++){const a=Math.random()*TAU,sp=(.03+Math.random()*.22)*(.5+v)*(1+T.fx1);S.parts.push({x:bx+(T.pan-.5)*.2,y:by,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,life:1,dec:.5+(1-T.rel)*1.2,s:1+v*3.5*(.6+T.cut),c:PAL[t]})}
  if(S.parts.length>1800)S.parts.splice(0,S.parts.length-1800);
  if(!S.playing)S.pulses.push({age:0,beat:true,bar:false,c:PAL[t]});break}
 case 'noteoff':{S.held.delete(e.ch+':'+e.note);recalc();for(let i=S.roll.length-1;i>=0;i--){const n=S.roll[i];if(n.ch===e.ch&&n.n===e.note&&n.b1==null){n.b1=S.beatPos;break}}break}
 case 'cc':{if(cfg.sceneCC&&e.cc===cfg.sceneCC){setScene(Math.floor(e.val/128*SCENES.length));return}
  if(e.cc===85&&cfg.followScene){setScene(e.val);return}
  if(e.cc===80){const b=Math.max(40,Math.min(220,e.val*2));S.bpmShow=b+'';return}
  const t=trackOf(e.ch),k=CC[e.cc];if(t<0||!k)return;const T=S.tracks[t],v=e.val/127;
  if(k[0]==='p'&&k.length===2)T.p[+k[1]]=v;else if(k==='vol')T.vol=v;else if(k==='mute')T.mute=e.val>0?1:0;else T[k]=v;break}}});
function recalc(){const prev=S.pcs.join('');S.pcs.fill(0);let tr=-1;for(const h of S.held.values()){S.pcs[h.pc]=1;tr=h.t}
 const held=[];for(let i=0;i<12;i++)if(S.pcs[i])held.push(i);
 if(held.length>=2){if(tr>=0)S.chordTrack=tr;const name=chordName(held);if(name!==S.chordName){S.chordName=name;if(S.chordHist[S.chordHist.length-1]!==name)S.chordHist.push(name);if(S.chordHist.length>12)S.chordHist.shift()}
  // morph polygon: reuse vertices, ease each angle to its new pitch class
  const old=S.chordPoly;S.chordPoly=held.map((pc,i)=>{const o=old[i]||old[old.length-1];const ta=pc/12*TAU;const v={a:o?o.a:ta,ta,p(cx,cy,R){const a=this.a-Math.PI/2;return[cx+Math.cos(a)*R,cy+Math.sin(a)*R]}};return v})}}
// demo: drift-free scheduler at 120 BPM. drums T1 (notes 53-76 like OP-XY drum keys), bass T2, chords T3, lead T4, guitar-ish arp T5
let demoT=null,demoStart=0,demoTick=0;const PROG=[[60,64,67,71],[57,60,64,67],[53,57,60,64],[55,59,62,65]];
function toggleDemo(on=!demo){demo=on;$('demo').classList.toggle('on',demo);clearInterval(demoT);if(!demo){MIDI.parse([0xFC]);return}
 const tickMs=60000/120/24;demoStart=performance.now();demoTick=0;MIDI.parse([0xFA]);
 demoT=setInterval(()=>{const now=performance.now();while(demoStart+demoTick*tickMs<=now){const ts=demoStart+demoTick*tickMs;MIDI.parse([0xF8],'demo',ts);
  if(demoTick%6===0){const s=(demoTick/6)%64;
   if(s%4===0)note(1,53,112);if(s%8===4)note(1,55,100);if(s%2===1)note(1,59,55+(s%4===3?25:0));
   if(s%16===0){const c=PROG[(s/16)|0];c.forEach(n=>note(3,n,82,1850));note(2,c[0]-24,104,420)}
   if(s%16===8)note(2,PROG[(s/16)|0][2]-24,90,200);
   if(s%3===0)note(4,72+[0,3,7,10,12,7][(s/3|0)%6],50+Math.random()*70,140);
   if(s%2===0){const c=PROG[(s/16)|0];note(5,c[(s/2)%4]+12,60,110)}
   MIDI.parse([0xB0,12,Math.round(64+63*Math.sin(demoTick/300))]);MIDI.parse([0xB3,13,Math.round(64+63*Math.cos(demoTick/410))])}
  demoTick++}},4)}
function note(ch,n,v,len=100){MIDI.parse([0x8f+ch,n,v|0]);setTimeout(()=>MIDI.parse([0x7f+ch,n,0]),len)}
// render
let W=0,H=0,DPR=1,last=performance.now();const ft=[];
function resize(){DPR=Math.min(window.devicePixelRatio||1,2);W=innerWidth;H=innerHeight;cv.width=Math.round(W*DPR);cv.height=Math.round(H*DPR);g.fillStyle='#000';g.fillRect(0,0,cv.width,cv.height)}
addEventListener('resize',resize);resize();
const lerp=(a,b,k)=>a+(b-a)*k;
function frame(now){const t0=performance.now(),dt=Math.max(0,Math.min(.05,(now-last)/1000));last=now;const k=1-Math.pow(.0001,dt);// ~fast ease
 for(const T of S.tracks){T.env*=Math.pow(.02+T.rel*.15,dt);T.envS=lerp(T.envS,T.env*(T.mute?.4:1),1-Math.pow(1e-6,dt))}
 S.energy*=Math.pow(.15,dt);S.energyS=lerp(S.energyS,S.energy,k);S.beatEnv*=Math.pow(.01,dt);
 for(let i=0;i<12;i++)S.pcsS[i]=lerp(S.pcsS[i],S.pcs[i],1-Math.pow(1e-4,dt));
 const hasHeld=S.chordPoly.length>1&&S.held.size>1;S.chordA=lerp(S.chordA,hasHeld?1:0,1-Math.pow(hasHeld?1e-5:.05,dt));
 for(const v of S.chordPoly){let d=v.ta-v.a;d=((d+Math.PI)%TAU+TAU)%TAU-Math.PI;v.a+=d*(1-Math.pow(1e-5,dt))}
 for(const r of S.grid)for(let i=0;i<16;i++)r[i]*=Math.pow(.3,dt);
 const live=S.lastTick&&now-S.lastTick<400;
 if(!live){S.phase+=dt*(S.bpm||120)/60*.0+dt*.5}
 S.phaseS=live?lerp(S.phaseS,S.phase,1-Math.pow(1e-6,dt)):S.phase;if(Math.abs(S.phaseS-S.phase)>2)S.phaseS=S.phase;
 S.stepS=lerp(S.stepS,S.step,1-Math.pow(1e-8,dt));if(Math.abs(S.stepS-S.step)>3)S.stepS=S.step;
 S.beatPos+=dt*(S.bpm||120)/60;
 S.pulses.forEach(p=>p.age+=dt*.7);S.pulses=S.pulses.filter(p=>p.age<1).slice(-48);
 for(const p of S.parts){p.x+=p.vx*dt;p.y+=p.vy*dt;const dr=Math.pow(.25,dt);p.vx*=dr;p.vy=p.vy*dr+dt*.03;p.life-=dt*p.dec}S.parts=S.parts.filter(p=>p.life>0);
 // ROLL range follows recent notes
 const rec=S.roll.filter(n=>S.beatPos-(n.b1??S.beatPos)<8);if(rec.length){const lo=Math.min(...rec.map(n=>n.n))-3,hi=Math.max(...rec.map(n=>n.n))+3;S.rollLo=lerp(S.rollLo,Math.min(lo,hi-24),.05);S.rollHi=lerp(S.rollHi,Math.max(hi,lo+24),.05)}
 const sc=SCENES[scene];g.setTransform(DPR,0,0,DPR,0,0);g.globalAlpha=sc.fade;g.globalCompositeOperation='source-over';g.fillStyle='#000';g.fillRect(0,0,W,H);
 g.save();try{sc.draw(g,S,W,H,dt)}catch(err){log('draw error: '+err.message)}g.restore();
 ft.push(performance.now()-t0);if(ft.length>240)ft.shift();
 if(showStats&&(now|0)%10<17){const avg=ft.reduce((a,b)=>a+b,0)/ft.length;$('stats').textContent=`draw ${avg.toFixed(2)} ms / fps ${fps.toFixed(0)}`}
 frames.push(now);while(frames[0]<now-1000)frames.shift();fps=frames.length;requestAnimationFrame(frame)}
let showStats=location.hash.includes('stats'),frames=[],fps=0;window.__perf=()=>({avgDraw:ft.reduce((a,b)=>a+b,0)/ft.length,maxDraw:Math.max(...ft),fps});
// UI
function buildMap(){$('map').innerHTML=chmap.map((c,i)=>`<label>${TRACK_LABEL[i]}<input type=number min=0 max=16 value=${c} data-i=${i}></label>`).join('');
 $('map').querySelectorAll('input').forEach(x=>x.onchange=()=>{chmap[x.dataset.i]=+x.value;localStorage.setItem('opxy.chmap',JSON.stringify(chmap))})}
buildMap();$('reset').onclick=()=>{chmap=DEF.slice();localStorage.removeItem('opxy.chmap');buildMap()};
['sceneCh','sceneCC','drumTrack'].forEach(k=>{$(k).value=cfg[k];$(k).onchange=()=>{cfg[k]=+$(k).value;saveCfg()}});
$('followScene').checked=cfg.followScene;$('followScene').onchange=()=>{cfg.followScene=$('followScene').checked;saveCfg()};
$('demo').onclick=()=>toggleDemo();$('fs').onclick=fs;$('mon').onclick=toggleMon;
$('inputs').onchange=e=>MIDI.sel=e.target.value;
function toggleMon(){$('monitor').classList.toggle('hidden');$('monitor').textContent=logBuf.join('\n')}
function fs(){document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen()}
addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(e.target.tagName==='INPUT'||e.target.tagName==='SELECT')return;
 if(k>='1'&&k<='9'){if(+k<=SCENES.length)setScene(+k-1)}else if(k==='arrowright'||k===' '){e.preventDefault();setScene(scene+1)}else if(k==='arrowleft')setScene(scene-1);
 else if(k==='d')toggleDemo();else if(k==='m')toggleMon();else if(k==='f')fs();else if(k==='h')$('panel').classList.toggle('hidden');
 else if(k==='s'){showStats=!showStats;$('stats').classList.toggle('hidden',!showStats)}});
MIDI.init((list,err)=>{const s=$('inputs');s.innerHTML='<option value="all">all inputs</option>'+list.map(i=>`<option value="${i.id}">${i.name}</option>`).join('');
 $('dev').textContent=err||(list.length?list.map(i=>i.name).join(', '):'NO DEVICE')});
setScene(scene);if(location.hash.includes('demo'))toggleDemo(true);if(location.hash.includes('panel'))$('panel').classList.remove('hidden');
if(showStats)$('stats').classList.remove('hidden');
const m=location.hash.match(/scene=(\d)/);if(m)setScene(+m[1]-1);
requestAnimationFrame(frame);
