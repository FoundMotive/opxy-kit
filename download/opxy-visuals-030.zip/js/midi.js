// Web MIDI layer: parses notes, CC, clock, start/stop. Emits plain events.
const MIDI={access:null,handlers:[],sel:'all',
 on(f){this.handlers.push(f)},emit(e){for(const f of this.handlers)f(e)},
 async init(onList){if(!navigator.requestMIDIAccess){onList([],'Web MIDI unsupported (use Chrome/Edge desktop)');return}
  try{this.access=await navigator.requestMIDIAccess({sysex:false})}catch(e){onList([],'MIDI permission denied');return}
  const refresh=()=>{const l=[...this.access.inputs.values()];l.forEach(i=>i.onmidimessage=m=>{if(this.sel==='all'||this.sel===i.id)this.parse(m.data,i.name,m.timeStamp)});onList(l)};
  this.access.onstatechange=refresh;refresh()},
 // Chrome delivers one complete message per event, so an event that starts with a status byte is handled on its own,
 // exactly like the original parser. Only an event that starts with a data byte (running status from other hosts) uses
 // the remembered status. Realtime bytes (F8-FF) never touch running status, so heavy clock cannot drop notes.
 run:0,
 parse(d,src="demo",ts=performance.now()){if(!d||!d.length)return;const L={0x80:2,0x90:2,0xA0:2,0xB0:2,0xC0:1,0xD0:1,0xE0:2};
  const s0=d[0];
  if(s0>=0xF8){for(const b of d)if(b>=0xF8)this.one([b],src,ts);return}
  if(s0>=0xF0){if(s0<0xF8)this.run=0;return this.one(Array.from(d),src,ts)}
  if(s0>=0x80){this.run=s0;const n=L[s0&0xf0];if(d.length<=n+1)return this.one(Array.from(d),src,ts);
   // packet with several messages: split, allowing running status and realtime bytes inside
   let i=0,s=s0;while(i<d.length){const b=d[i];if(b>=0xF8){this.one([b],src,ts);i++;continue}
    if(b>=0xF0){this.run=0;break}if(b&0x80){s=b;this.run=b;i++}
    const k=L[s&0xf0],m=[s];while(m.length<=k&&i<d.length){if(d[i]>=0xF8){this.one([d[i]],src,ts);i++;continue}m.push(d[i++])}
    if(m.length===k+1)this.one(m,src,ts)}return}
  if(!this.run)return this.emit({type:'raw',bytes:Array.from(d),src});
  return this.parse([this.run,...d],src,ts)},
 one(d,src,ts){const s=d[0],t=s&0xf0,ch=(s&0x0f)+1;
  if(s===0xF8)return this.emit({type:"clock",ts});if(s===0xFA)return this.emit({type:'start'});if(s===0xFB)return this.emit({type:'continue'});if(s===0xFC)return this.emit({type:'stop'});
  if(t===0x90&&d[2]>0)return this.emit({type:'noteon',ch,note:d[1],vel:d[2],src,ts});
  if(t===0x80||(t===0x90&&d[2]===0))return this.emit({type:'noteoff',ch,note:d[1],src,ts});
  if(t===0xB0)return this.emit({type:'cc',ch,cc:d[1],val:d[2],src});
  if(t===0xE0)return this.emit({type:'bend',ch,val:((d[2]<<7)|d[1])-8192,src});
  if(s!==0xFE)this.emit({type:'raw',bytes:Array.from(d),src})}};
