// Scenes. draw(g, S, w, h, dt): coordinates in CSS pixels (app.js applies devicePixelRatio).
const PAL=['#ff6a00','#ffc31f','#2fb4ff','#ff3b6b','#6dff8a','#b48cff','#f2f2f2','#8f969c','#ff6a00','#ffc31f','#2fb4ff','#ff3b6b','#6dff8a','#b48cff','#f2f2f2','#8f969c'];
const NAMES=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
const TRACK_LABEL=['T1','T2','T3','T4','T5','T6','T7','T8','BRN','PNC','EXT','CV','AUD','TAP','FX1','FX2'];
const ease={out:t=>1-Math.pow(1-t,3),inOut:t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2,expo:t=>t>=1?1:1-Math.pow(2,-10*t)};
const TAU=Math.PI*2;
function st(g,c,a,w){g.strokeStyle=c;g.globalAlpha=Math.max(0,Math.min(1,a));g.lineWidth=w||1}
function txt(g,s,x,y,size,c,a,align){g.globalAlpha=a==null?1:a;g.fillStyle=c||'#fff';g.font=`${size>40?200:400} ${size}px "Helvetica Neue",Helvetica,Arial,sans-serif`;g.textAlign=align||'left';g.fillText(s,x,y)}
function dot(g,x,y,r,c,a){g.globalAlpha=Math.max(0,Math.min(1,a));g.fillStyle=c;g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}
const SCENES=[
{name:'RINGS',fade:1,draw(g,S,w,h){const cx=w/2,cy=h/2,m=Math.min(w,h),R0=m*.07,dr=m*.026;
 for(let t=0;t<16;t++){const T=S.tracks[t],r=(R0+dr*t)*(.96+.04*T.vol),e=T.envS,aux=t>=8;
  st(g,e>.01?PAL[t]:'#fff',(aux?.08:.14)+e*.5,1+e*1.5);if(aux)g.setLineDash([2,4]);g.beginPath();g.arc(cx,cy,r,0,TAU);g.stroke();g.setLineDash([]);
  if(T.last>=0&&e>.002){const a0=(T.last%12)/12*TAU-Math.PI/2,span=(.15+T.vel*.9)*(.3+e*.7);
   st(g,PAL[t],.25+e*.75,1.2+e*2.6*(.5+T.cut));g.beginPath();g.arc(cx,cy,r,a0-span/2,a0+span/2);g.stroke();
   dot(g,cx+Math.cos(a0)*r,cy+Math.sin(a0)*r,1.5+e*3.5,PAL[t],e)}}
 const Rmax=R0+dr*16;for(let i=0;i<16;i++){const a=i/16*TAU-Math.PI/2,on=i===S.step%16;st(g,on?'#ff6a00':'#fff',on?1:.3,on?2:1);
  g.beginPath();g.moveTo(cx+Math.cos(a)*Rmax,cy+Math.sin(a)*Rmax);g.lineTo(cx+Math.cos(a)*(Rmax+(i%4?6:12)),cy+Math.sin(a)*(Rmax+(i%4?6:12)));g.stroke()}
 const a=S.phaseS/4*TAU-Math.PI/2;st(g,'#fff',.55,1);g.beginPath();g.moveTo(cx+Math.cos(a)*R0*.5,cy+Math.sin(a)*R0*.5);g.lineTo(cx+Math.cos(a)*Rmax,cy+Math.sin(a)*Rmax);g.stroke();
 dot(g,cx,cy,3+S.beatEnv*5,'#ff6a00',1);
 for(let t=0;t<8;t++){const y=cy+(R0+dr*t);txt(g,TRACK_LABEL[t],cx+6,y-3,9,'#fff',.35)}}},
{name:'GRID',fade:1,draw(g,S,w,h){const padX=w*.08,padY=h*.14,cols=16,rows=8,cw=(w-padX*2)/cols,rh=(h-padY*2)/rows,step=S.step%16;
 for(let c=0;c<cols;c++){txt(g,String(c+1).padStart(2,'0'),padX+c*cw+cw/2,padY-14,9,c===step?'#ff6a00':'#fff',c===step?1:.35,'center')}
 const sx=padX+(S.stepS%16)*cw;g.globalAlpha=.06;g.fillStyle='#fff';g.fillRect(sx,padY,cw,rows*rh);
 for(let r=0;r<rows;r++){txt(g,TRACK_LABEL[r],padX-14,padY+r*rh+rh/2+3,9,PAL[r],.8,'right');
  for(let c=0;c<cols;c++){const v=S.grid[r][c],x=padX+c*cw+cw/2,y=padY+r*rh+rh/2,s=Math.min(cw,rh)*.62;
   if(v<.02){dot(g,x,y,1,'#fff',c%4?.25:.5);continue}
   const k=ease.out(v);st(g,PAL[r],.35+.65*k,1);g.strokeRect(x-s/2,y-s/2,s,s);g.globalAlpha=k*.9;g.fillStyle=PAL[r];const f=s*(.25+.6*k);g.fillRect(x-f/2,y-f/2,f,f)}}}},
{name:'PULSE',fade:1,draw(g,S,w,h){const cx=w/2,cy=h*.46,m=Math.min(w,h);
 for(const p of S.pulses){const k=ease.out(Math.min(1,p.age)),r=k*m*(p.beat?.62:.42),a=(1-k)*(p.bar?1:.7);
  if(p.beat){st(g,p.c,a,p.bar?2.5:1.2);g.beginPath();g.arc(cx,cy,r,0,TAU);g.stroke()}else{st(g,p.c,a*.6,1);g.save();g.translate(cx,cy);g.rotate(Math.PI/4);g.strokeRect(-r*.7,-r*.7,r*1.4,r*1.4);g.restore()}}
 dot(g,cx,cy,5+ease.out(S.beatEnv)*16,S.playing?'#ff6a00':'#555',.4+.6*S.beatEnv);
 const beat=Math.floor(S.clocks/24)%4;for(let i=0;i<4;i++)dot(g,cx-27+i*18,cy+m*.25,i===beat&&S.playing?4:2,i===beat&&S.playing?'#fff':'#666',1);
 txt(g,S.bpmShow,cx,cy+m*.4,m*.11,'#fff',1,'center');txt(g,'BPM',cx,cy+m*.45,10,'#fff',.45,'center');
 txt(g,'BAR '+(1+Math.floor(S.clocks/96))+'.'+(1+beat),w-24,32,11,'#fff',.6,'right')}},
{name:'CHORD',fade:1,draw(g,S,w,h){const cx=w/2,cy=h/2,R=Math.min(w,h)*.32;
 st(g,'#fff',.2,1);g.beginPath();g.arc(cx,cy,R,0,TAU);g.stroke();
 const pt=(i,rr=R)=>{const a=i/12*TAU-Math.PI/2;return[cx+Math.cos(a)*rr,cy+Math.sin(a)*rr]};
 for(let i=0;i<12;i++){const v=S.pcsS[i],[x,y]=pt(i),[lx,ly]=pt(i,R*1.13);dot(g,x,y,1.5+v*5,v>.05?'#fff':'#777',.4+v*.6);txt(g,NAMES[i],lx,ly+4,11,'#fff',.3+v*.7,'center')}
 // eased polygon: vertices drift toward targets
 const V=S.chordPoly;if(V.length>1){const col=PAL[S.chordTrack];
  for(let i=0;i<V.length;i++)for(let j=i+2;j<V.length+(i?0:-1);j++){st(g,col,.12*S.chordA,1);g.beginPath();g.moveTo(...V[i].p(cx,cy,R));g.lineTo(...V[j].p(cx,cy,R));g.stroke()}
  g.beginPath();V.forEach((v,k)=>{const[x,y]=v.p(cx,cy,R);k?g.lineTo(x,y):g.moveTo(x,y)});g.closePath();g.globalAlpha=.1*S.chordA;g.fillStyle=col;g.fill();st(g,col,S.chordA,2);g.stroke()}
 txt(g,S.chordName,cx,cy+R*.09,R*.24,'#fff',S.chordA,'center');
 {let x=24;S.chordHist.slice(-6).forEach((c,i,arr)=>{txt(g,c,x,h-48,13,'#fff',.25+.75*(i+1)/arr.length);x+=g.measureText(c).width+28})}}},
{name:'GRAINS',fade:.18,draw(g,S,w,h){g.globalCompositeOperation='lighter';
 for(const p of S.parts){const k=p.life;dot(g,p.x*w,p.y*h,p.s*(.4+.6*k),p.c,k*k)}g.globalCompositeOperation='source-over';
 for(let t=0;t<8;t++){const e=S.tracks[t].envS;st(g,PAL[t],.2+e*.8,1);const x=w*.1+t*w*.8/7;g.beginPath();g.moveTo(x-12,h-30);g.lineTo(x+12,h-30);g.stroke();
  g.globalAlpha=e;g.fillRect(x-12,h-30-e*40,24,1.5)}}},
{name:'SCOPE',fade:.22,draw(g,S,w,h){const cx=w/2,cy=h/2,R=Math.min(w,h)*.36,T=S.tracks[S.lastTrack],P=T.p;
 const a=1+P[0]*6,b=1+P[1]*6,d=P[2]*Math.PI,e=S.energyS;
 for(let k=0;k<3;k++){st(g,k?PAL[(S.lastTrack+k*2)%16]:'#fff',k?.3:.85,k?1:1.4);g.beginPath();
  for(let i=0;i<=720;i++){const t=i/720*TAU,wob=1+e*.08*Math.sin(t*(8+P[3]*24)+S.phaseS*TAU);
   const x=cx+Math.sin(a*t+d+S.phaseS*.5+k*.04)*R*wob,y=cy+Math.sin(b*t)*R*wob*(1-k*.03);i?g.lineTo(x,y):g.moveTo(x,y)}g.stroke()}
 txt(g,`A ${a.toFixed(2)}  B ${b.toFixed(2)}  PH ${(d/Math.PI).toFixed(2)}`,24,32,11,'#fff',.5)}},
{name:'ROLL',fade:1,draw(g,S,w,h){// bonus: clock-synced piano roll, good for keys and guitar parts
 const now=S.beatPos,span=8,lo=S.rollLo,hi=S.rollHi,ph=(hi-lo+1),nx=b=>w*.9-(now-b)/span*w*.8,ny=n=>h*.88-(n-lo)/ph*h*.76;
 for(let b=Math.ceil(now-span);b<=now;b++){const x=nx(b);st(g,'#fff',b%4?.08:.25,1);g.beginPath();g.moveTo(x,h*.1);g.lineTo(x,h*.9);g.stroke()}
 st(g,'#ff6a00',.9,1);g.beginPath();g.moveTo(w*.9,h*.1);g.lineTo(w*.9,h*.9);g.stroke();
 const nh=Math.max(2,h*.76/ph-1);for(const n of S.roll){const x0=nx(n.b0),x1=nx(n.b1==null?now:n.b1);if(x1<w*.1)continue;
  g.globalAlpha=.35+.65*n.v;g.fillStyle=PAL[n.t];g.fillRect(Math.max(w*.1,x0),ny(n.n)-nh/2,Math.max(2,x1-Math.max(w*.1,x0)),nh);
  if(n.b1==null)dot(g,w*.9,ny(n.n),3,'#fff',1)}
 for(let n=lo;n<=hi;n++)if(n%12===0)txt(g,'C'+(Math.floor(n/12)-1),w*.1-10,ny(n)+3,9,'#fff',.4,'right')}}
];
function chordName(pcs){if(!pcs.length)return '';if(pcs.length===1)return NAMES[pcs[0]];
 const Q=[['',[0,4,7]],['m',[0,3,7]],['dim',[0,3,6]],['aug',[0,4,8]],['sus2',[0,2,7]],['sus4',[0,5,7]],['7',[0,4,7,10]],['maj7',[0,4,7,11]],['m7',[0,3,7,10]],['m7b5',[0,3,6,10]],['dim7',[0,3,6,9]],['5',[0,7]],['6',[0,4,7,9]],['m6',[0,3,7,9]],['add9',[0,2,4,7]],['9',[0,2,4,7,10]],['maj9',[0,2,4,7,11]],['m9',[0,2,3,7,10]]];
 for(const r of pcs)for(const[n,iv]of Q){const set=iv.map(i=>(r+i)%12);if(set.length===pcs.length&&set.every(x=>pcs.includes(x)))return NAMES[r]+n}
 return pcs.map(p=>NAMES[p]).join(' ')}
