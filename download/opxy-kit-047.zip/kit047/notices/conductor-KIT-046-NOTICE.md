# Conductor in open-xy kits 031 to 046

Conductor is by Max Mockett (mmockett), MIT licensed. See LICENSE in this folder,
which is kept as published. Source: Conductor commit 52cfa23.

It needs the track control and aux track SDK work from Max Mockett's
sdk/control-notes branch (open-xy issue #345, PRs #198 and #234), ported into
this kit on top of the Open-XY SDK by etcetc000 (P.E. Viau) and contributors.

Kit 031 changes one thing in the machine: definition.json drops "hidePages",
which the SDK removed upstream (commit 5f22944, aux machines own their pages)
and now refuses. The kit layout gives it engine 50, page 98. Tempo comes from the project (bpm_x10), and note
positions follow the device's song position, so no manual BPM control is needed.

Kit 032 rewrites the generator, words, display and controls of Conductor for
lofi only (generator.h, specs.h, words.h, display.cpp, control.cpp,
definition.json, tests). These changes are by the kit maintainers, under the
same MIT license; Max Mockett's copyright and LICENSE are kept. The chord
progressions, grooves and patterns are generic, written for this kit, not
taken from any song or dataset. Ideas only from Magenta GrooVAE and Lofi Player.

Kit 033 replaces the lofi libraries with rule based generators (chord grammar,
motif development, probabilistic grooves, bass and song form) in generator.h, by
the kit maintainers under the same MIT license. Nothing is taken from any song
or dataset.

Kit 034 draws the drum grooves from statistics of the Groove MIDI Dataset
(Google LLC, CC BY 4.0, https://magenta.tensorflow.org/datasets/groove;
Gillick et al., ICML 2019). gmd_tables.h holds only derived per step
numbers (hit odds, velocities, timing, common kick bars, fill shapes); no MIDI
from the dataset is included. The dataset is unchanged and not redistributed.

The classic style grids in generator.h (kClassics) are short step patterns
written for this kit by feel; they are not samples, transcriptions or
official reproductions of any recording.

Kit 035 retunes the default feel (Swing and Lazy defaults, MPC style swing
mapping, per part timing in ms) in generator.h, control.cpp and
definition.json, by the kit maintainers under the same MIT license. The
numbers follow published producer and research figures cited in the kit
notes; no code or data is taken from them.

Kit 036, by the kit maintainers under the same MIT license:
- SDK port (sdk/platform/opxy-1.2.1/track_control.cpp): notes start with a
  gate far longer than any note, so stock no longer ends them after its key
  preview's short gate; the SDK's own note-off ends each note at its length.
  This is a change to the track control port of Max Mockett's
  sdk/control-notes work, on the Open-XY SDK by etcetc000 (MIT); both
  credits are kept.
- Conductor (generator.h, specs.h, words.h, display.cpp, tests): per lane note
  lengths (keys, pad, melody articulation, bass), a perc lane on t2 and a
  hook counter-melody on t8; roles now take 4 bits each in the display words.
- Stale presets: the aux preset list (aux_tracks.cpp, with the list of names
  from tooling/adapters.py) hides files in content/aux_presets/<machine>/ that
  this build does not install, such as kit 031's Pop, Night and Jazz. Nothing
  is deleted, and the user's /fat32/aux_presets is always listed. If an old
  name still shows, it is a user copy in /fat32/aux_presets/conductor/; copy
  it off the device and move it out of that folder to drop it.
- Drum statistics remain derived from the Groove MIDI Dataset (Google LLC,
  CC BY 4.0) as described above; the new perc lane uses no dataset numbers.

Kit 037, by the kit maintainers under the same MIT license:
- Conductor keys (generator.h): pushes restrike only the top voices over held
  lower ones, common tones tie across chord changes, each pitch sounds once
  per chord, a note ends before its key strikes again, rarer pushes, softer
  top voices.
- Conductor colour (generator.h): a per song darkness that trims high
  extensions, lowers and sometimes opens the keys voicing, and borrows minor
  iv, bVI, bVII and a modal minor v, keeping home bars and the cadence.
- A test (tests/conductor.cpp) that the keys never strike a pitch still
  sounding and that darkness varies by song. Drums, perc and song form are
  unchanged.
- The Open-XY SDK credit (etcetc000, MIT), Max Mockett's Conductor credit
  (MIT) and the Groove MIDI Dataset credit (Google LLC, CC BY 4.0) above
  are kept.

Kit 038, by the kit maintainers under the same MIT license:
- SDK port (sdk/platform/opxy-1.2.1/track_control.cpp): notes start with the
  held key's arguments (gate -1, live key flag 0x20, no record flag), as the
  stock keyboard path at 8d594376 sends them, so synth engines sustain each
  note until the SDK's own note-off. A change to the track control port of
  Max Mockett's sdk/control-notes work on the Open-XY SDK by etcetc000 (MIT);
  both credits are kept.
- Conductor (generator.h): a velocity model on the melodic lanes (beat
  accents, ghost and passing notes, phrase swells and fades, section
  dynamics, voice balance, small humanisation), still scaled by Vel.
- Tests: a host model of an engine voice that stays in gate only under the
  held key form, for exactly the note's length, with velocities passed
  through unchanged (tests/fixtures/track_control.cpp), and a velocity
  spread check per melodic lane (tests/conductor.cpp). Drums are unchanged.
- The Open-XY SDK credit (etcetc000, MIT), Max Mockett's Conductor credit
  (MIT) and the Groove MIDI Dataset credit (Google LLC, CC BY 4.0) above
  are kept.

Kit 039 adds two diagnostics on M4 (start mode, a 4 s test note on t4), a
saved data version "CND3" that moves songs saved as "CND2" over and gives
lanes 7 and 8 perc and counter when they were off, and more present perc and
counter in generator.h, by the kit maintainers under the same MIT license.

Kit 040 changes how the SDK ends Conductor's notes (track_control.cpp): each
held note ends at its own scheduled off, counted in song ticks at the tempo,
with the cycle clock only as a backup; a machine missing from its track for
under 16 GUI ticks keeps its notes. M4 with Shift shows how notes ended, by
cause. By the kit maintainers under the same MIT license. The Open-XY SDK
credit (etcetc000, MIT), Max Mockett's Conductor credit (MIT) and the Groove
MIDI Dataset credit (Google LLC, CC BY 4.0) above are kept.

Kit 041 changes how the SDK starts and keeps Conductor's notes
(track_control.cpp): notes use source id 0x2a instead of the keyboard's
source 1, so stock's keyboard and bulk release paths no longer end them as
their own; a pitch Conductor already holds on a track is kept and extended
instead of being struck again; and the M4 + Shift clock counter now counts
every playing tick. Conductor itself is unchanged. By the kit maintainers
under the same MIT license. The Open-XY SDK credit (etcetc000, MIT), Max
Mockett's Conductor credit (MIT) and the Groove MIDI Dataset credit (Google
LLC, CC BY 4.0) above are kept.

Kit 042 makes Conductor's drums and perc strike every hit again in kit 036's
gated form and restores kit 036's perc generator. Only keys and pad tie a
chord tone they still hold; every other lane strikes each note. Conductor is
by Max Mockett (MIT); open-xy is by etcetc000 (MIT). All credits are kept.

Kit 043 sends Conductor's drum and perc notes through kit 036's exact stock
call (source 1) and keeps source 0x2a for every other lane. Conductor is by
Max Mockett (MIT); open-xy is by etcetc000 (MIT). All credits are kept.

Kit 044 plays every Conductor drum and perc hit on its exact OP-XY drum
pad at keyboard +0, with no octave, transpose or range fold. Conductor is by
Max Mockett (MIT); open-xy is by etcetc000 (MIT). All credits are kept.

Kit 045 returns Conductor's drums and perc to kit 036 in every respect and adds
start mode D, kit 036's call on every lane. Conductor is by Max Mockett (MIT);
open-xy is by etcetc000 (MIT). All credits are kept.

Kit 046 changes how t1 and t2 drums are sent and adds a drum key map
(generator.h, specs.h, words.h, control.cpp, tests/kit046), by the kit
maintainers under the same MIT license. Drums now use the SDK's start_key
call, the same key-down and key-up path as a hand press, with a gate that
ends before the next hit on the same pad (at least 30 ms), and the same pad is
not struck twice within 20 ms. Each drum voice (kick, snare, clap, rim, closed
hat, open hat, shaker, perc, low tom, high tom) plays a pad from a per project
key map, editable on the device. Max Mockett's copyright and LICENSE are kept,
as are the Groove MIDI Dataset (CC BY 4.0) credits above.
