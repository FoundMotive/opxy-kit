# Found Motive OP-XY kit 048 (open-xy SDK 1.10, OP-XY OS 1.2.1)

Unofficial. This is a personal build of the open-xy browser builder. It is not
made, checked or supported by Teenage Engineering, and it is not an official
open-xy release. Use it at your own risk.

## Urgent kit 047 boot-crash fix

Do not flash kit 047. It can crash the OP-XY on boot because FM Chord's
compiled screen filename did not match its packaged display asset.
Kit 048 fixes that mismatch to scalechord.svg without changing the fm chord
project/catalog type. This was not caused by selecting community plugins.
This build has software verification only and has not been tested on hardware.
Unofficial firmware can leave a device unable to boot. Back up your projects
and keep stock firmware available before attempting any update.

## Open the builder

Unzip, then open opxy-builder.html in a desktop Chrome or Edge (double click it,
or drag it into a browser window). Everything runs in the browser; nothing is
uploaded. Give it your own stock OP-XY OS 1.2.1 os.ldr when it asks; the kit
does not include stock firmware.

To keep machine numbers the same as earlier Found Motive kits (so saved
projects find their machines), load layout.json from this zip with the
builder's layout button before you build.

## Picking machines

Every machine has a checkbox. Tick what you want and untick what you do not.
Nothing is locked. The list is in three groups:

* Found Motive: our own machines, at the top. They start checked, except
  Electric, which starts unchecked because it does not fit beside the rest.
* Core: open-xy's own engines (fm2op, karplus, ringmod, pingpong start
  checked; macroosc and chords start unchecked, see Memory).
* Community: machines from the open-xy catalog by other authors. They all start
  unchecked. Each one shows its author and source.

The Graphics option can switch machine screens to grayscale. It starts off.

## Memory meter

All chosen machines share one 2032 KiB module. The meter at the top shows how
much the current choice uses. If it says the selection cannot be built, untick
something. The default choice uses 2,035,712 bytes (1988.0 KiB).

Under SDK 1.10 the shared SDK code and the newest macroosc are larger than in
kit 046, so the full kit 046 set no longer fits together. Macroosc therefore
starts unchecked. Tick it and untick Guitar (or another large machine) if you
want it.

## Community machines

Community machines are written by other people and were not reviewed by us.
They may use a lot of memory or CPU, may misbehave together, and may change
how a project sounds. Add them a few at a time and test before you rely on a
project.

## Recovery

If the OP-XY does not start after an update, hold COM while you power it on to
reach update mode, then install the official stock OP-XY OS 1.2.1 os.ldr,
or a known-good earlier Found Motive kit such as 046, 031 or 028b. Do not
reinstall 047. Follow Teenage Engineering's firmware update instructions.

## Credits

* OP-XY and its stock OS: Teenage Engineering. Thanks for a wonderful
  instrument. This kit only patches a copy of the OS you provide.
* Open-XY SDK and builder: etcetc000 and the Open-XY contributors (MIT).
* Conductor: Max Mockett (mmockett), MIT, with Groove MIDI Dataset statistics
  (Google LLC, CC BY 4.0).
* Found Motive machines: Kieran.
* Core machines (fm2op, macroosc, karplus, ringmod, pingpong, chords): Open-XY.
* Community machines, by author:

* Hurdy Gurdy (hurdygurdy): SammiBabe666, https://github.com/etcetc000/open-xy-hurdygurdy v1.3.1
* Nightdrive (nightdrive): V714, https://github.com/V714/open-xy-nightdrive v1.0.1
* Oldsun (oldsun): etcetc000, https://github.com/etcetc000/open-xy-oldsun v0.20.2
* Metal (metal): johnnywagner, https://github.com/johnnywagner/open-xy-metal v1.1.0
* matriXY (matrixy): frankoooooooo, https://github.com/frankoooooooo/matrixy v1.0.2
* Troupe (troupe): Hecedu, https://github.com/Hecedu/open-xy-troupe v1.0.1
* FM DYN (mmdyn): mmockett, https://github.com/mmockett/OP-XY-MNMD v1.2.3
* SWAVE-ENS (mmens): mmockett, https://github.com/mmockett/OP-XY-MNMD v1.1.9
* FM PAR (mmpar): mmockett, https://github.com/mmockett/OP-XY-MNMD v1.2.3
* SWAVE-PULSE (mmpulse): mmockett, https://github.com/mmockett/OP-XY-MNMD v1.1.9
* SID-6581 (mmsid): mmockett, https://github.com/mmockett/OP-XY-MNMD v1.1.9
* FM STAT (mmstat): mmockett, https://github.com/mmockett/OP-XY-MNMD v1.2.3
* VO-6 (mmvo6): mmockett, https://github.com/mmockett/OP-XY-MNMD v1.2.3
* breadboard (breadboard): lowlevelgamedev, https://github.com/meemknight/OPXY-breadboard v1.1.0
* Grains (grains): mmockett, https://github.com/mmockett/OP-XY-Grains v1.2.0
* Wane (wane): mmockett, https://github.com/mmockett/OP-XY-Hexagon v1.1.0
* Bloom (bloom): mmockett, https://github.com/mmockett/OP-XY-Hexagon v1.5.0
* Hollow (hollow): mmockett, https://github.com/mmockett/OP-XY-Hexagon v1.3.0
* Orbit (orbit): mmockett, https://github.com/mmockett/OP-XY-Hexagon v1.2.0
* Bend (bend): mmockett, https://github.com/mmockett/OP-XY-Hexagon v1.2.0
* Moth (moth): mmockett, https://github.com/mmockett/OP-XY-Hexagon v1.6.0
* Sand (sand): mmockett, https://github.com/mmockett/OP-XY-Nonagon v0.5.0
* Cocoa (cocoa): mmockett, https://github.com/mmockett/OP-XY-Nonagon v0.6.0
* Coin (coin): mmockett, https://github.com/mmockett/OP-XY-Nonagon v0.6.0
* Fermi (fermi): mmockett, https://github.com/mmockett/OP-XY-Nonagon v0.6.0
* Mach (mach): mmockett, https://github.com/mmockett/OP-XY-Nonagon v0.7.2
* Butterfly (butterfly): mmockett, https://github.com/mmockett/OP-XY-Nonagon v0.6.0
* Drop (drop): mmockett, https://github.com/mmockett/OP-XY-Nonagon v0.6.0
* Ghost (ghost): mmockett, https://github.com/mmockett/OP-XY-Nonagon v0.8.0
* Recur (recur): mmockett, https://github.com/mmockett/OP-XY-Nonagon v0.8.0
* MD KIT (mdkit): mmockett, https://github.com/mmockett/OP-XY-MNMD v1.2.2
* SWAVE-SAW (mmsaw): mmockett, https://github.com/mmockett/OP-XY-MNMD v1.1.9
* GND-SIN (mmsin): mmockett, https://github.com/mmockett/OP-XY-MNMD v1.1.9
* GND-NOIS (mmnois): mmockett, https://github.com/mmockett/OP-XY-MNMD v1.2.3
* Lint (lint): mmockett, https://github.com/mmockett/OP-XY-ModFX v1.8.0
* Chroma (chroma): mmockett, https://github.com/mmockett/OP-XY-ModFX v1.7.0
* Daath (daath): SammiBabe666, https://github.com/SammiBabe666/Daath-OP-XY-WitchHouse-engine 1.0
* Tattva (tattva): colorsinspace1, https://github.com/colorsinspace1/tattva 1.02
* Grainfield (grainfield): colorsinspace1, https://github.com/colorsinspace1/grainfield 1.2
* Ohmonk (ohmonk): hatchman, https://github.com/hatchman/open-xy-ohmonk v1.0.0
* Chimes (chimes): carlosedp, https://github.com/carlosedp/open-xy-eurorack v1.2.0
* Cirrus (cirrus): carlosedp, https://github.com/carlosedp/open-xy-eurorack v1.3.0
* Halcyon (halcyon): colorsinspace1, https://github.com/colorsinspace1/halcyon 1.3
* Wander (wander): colorsinspace1, https://github.com/colorsinspace1/wander 1.0
* Halcyon Keys (hkeys): colorsinspace1, https://github.com/colorsinspace1/halcyon-keys 1.4
* Halcyon Wander (hwander): colorsinspace1, https://github.com/colorsinspace1/halcyon-wander 1.6
* Acid Rain (acidrain): frankoooooooo, https://github.com/frankoooooooo/acid-rain v1.0.1

Full license texts are in the notices folder.
