# Kit 030

Kit 029 plus fixes and new guitar patterns, for OP-XY on stock OS 1.2.1 only.
The builder reads the OS from your device; nothing here contains firmware.

## What changed

- **FM Chord works on a fresh 1.2.1 device.** Root cause: kit 029 read the
  OS Maestro note records at the OS 1.2.0 offsets (records +0x1dc, held count
  +0x41c). On 1.2.1 they are at +0x10c and +0x34c, so on a fresh device the
  player saw garbage, played no chord and passed the key through, which
  sustained one note until stop. Kit 030 uses the 1.2.1 offsets, initializes
  its own state, releases a note before it is pressed again, evicts the oldest
  record when full and bounds the held count. Setups that worked before play
  the same chords.
- **FM Gtr: 15 new strum patterns** (pop, rock, alt rock; 4/4 and 3/4,
  labels of 8 characters or less). The 15 old patterns are kept and sound the
  same. Chords can still change mid-pattern without a restart.
- **FM Piano: cleaner and a little lighter.** A 4x finer sine table (phase
  grit about 11 dB lower), partials ramp to each new strike level instead of
  jumping, quiet partials fade out and are skipped, and the partial loop is
  hand pipelined on the Blackfin.
- **FM Cloud: the default patch is heard at once.** A new note starts with a
  full cloud of grains under a 3 ms fade-in, instead of swelling in over
  about 100 ms or more.
- **New machine: Electric** (engine 49, page 97). An electric guitar built
  like the acoustic one: six plucked strings that ring under the strum
  patterns, then a drive stage and a small cabinet. It has all 30 acoustic
  patterns, 10 new riff patterns (power chords, palm mutes, gallop, alt rock)
  and two key modes: Notes, and Lead, a single legato voice where a new key
  slides from the last one, the pitch bend follows at once and a delayed
  vibrato comes in on held notes. Presets: default, clean, gallop, altrock,
  riff-34 and lead. Chords change mid-pattern without a restart, the same as
  the acoustic guitar.

## Please note

- **Saved projects:** a project saved under kit 029 may land on a
  neighbouring guitar pattern, because the pattern knob now has 30 steps.
  The kit's own presets were re-centred and pick the same patterns.
- **Piano crackle needs a hardware listen.** The fixes above remove the
  crackle sources found in simulation. If it still crackles on the device,
  the next suspect is clipping where the OS sums the voices.

## CPU (devsim, worst cycles per 64-sample block; budget 580,000)

| Engine | kit 029 | kit 030 | Sound |
|---|---|---|---|
| FM VTune | 168,976 | 168,976 | identical |
| Karplus | 157,853 | 157,853 | identical |
| FM Gtr pattern (old patterns) | 135,811 | 135,876 | identical |
| FM Gtr pattern (new patterns) | n/a | 137,131 | new |
| Electric (worst of riffs, strums, lead) | n/a | 125,151 | new |
| FM Choir (8 keys) | 131,561 | 131,561 | identical |
| FM Cloud | 59,075 | 94,432 | changed (fast start) |
| FM Piano (8 voices) | 81,424 | 79,912 | changed |
| FM Piano (1 voice) | 10,174 | 9,985 | changed |
| FM GKit | 40,571 | 40,571 | identical |
| FM Tape | 39,686 | 39,686 | identical |
| PingPong | 35,742 | 35,742 | identical |
| FM Bass | 15,220 | 15,220 | identical |
| FM Shakr | 13,639 | 13,639 | identical |
| FM Phase | 11,273 | 11,273 | identical |
| FM Loop | 11,256 | 11,256 | identical |
| 2op | 6,423 | 6,423 | identical |

Piano average (8 voices) went from 69,541 to 66,261 cycles. Cloud's worst
block is the first block of a note, when the whole cloud starts.

## Tests

- sdk.py check: pass.
- Fixed-kit install tests, each its own run: no layout, the kit 016 layout,
  the kit 026 layout: all pass.
- Devsim: every engine not named above as changed has the same render hash
  as kit 029 (docs/kit-030/devsim-030.txt).
- Chord host test (tests/kit030/chord_records.cpp), from leftover RAM with
  some note-offs lost: kit 029 played 0 of 2400 chords, kit 030 plays all
  2400.

Host and simulator checks only.

## Needs a hardware test

- FM Chord on a fresh 1.2.1 device, and on a setup that already worked.
- Keys passed through with chord mode Off get their note-offs.
- Piano crackle (see above).
- Cloud's default patch sounds at once.
- Electric on the device: tone and drive, level against the other
  machines, riffs in time, Lead legato slides, bends and vibrato.

Rebuild: tools/port_kit030.sh.

Credits: built on etcetc000's open-xy (MIT); see LICENSE. Thank you,
etcetc000.
