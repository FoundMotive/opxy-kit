# Kit 029

Kit 028b for OP-XY OS 1.2.1. Merges etcetc000's open-xy 6941bc8 (SDK 0.0.3,
OS 1.2.1, MIT) into kit 028b (d66bd13). Same 17 machines, same names on the
device, same engine and page numbers as kit 028b. Every engine sounds exactly
as in kit 028b: all devsim render hashes are identical.

Install it only on a device running stock OS 1.2.1. The builder reads the OS
from your device; nothing here contains firmware.

## What changed

- OS 1.2.1 support and SDK 0.0.3 from upstream (extensions, page headers,
  double tap, 18-bit pad settings, the new voice slot code).
- The kit's own OS hooks were moved from 1.2.0 to 1.2.1 by etcetc000's
  `tools/os_port.py` through `tools/kit029_port.py`: 6 profile hooks (the
  player extension used by FM Chord) and 46 stock addresses, all matched by
  bytes. Details and fingerprints: docs/kit-029/HOOKS.md.
- A fixed kit no longer recovers a partial selection.

## CPU (devsim, worst cycles per 64-sample block; budget 580,000)

| Engine | kit 028b | kit 029 | Sound |
|---|---|---|---|
| FM VTune | 168,976 | 168,976 | identical |
| FM Gtr pattern | 135,811 | 135,811 | identical |
| FM Choir (8 keys) | 131,561 | 131,561 | identical |
| Karplus | 157,853 | 157,853 | identical |
| FM Piano (8 voices) | 81,424 | 81,424 | identical |
| FM Cloud | 59,084 | 59,075 | identical |
| FM GKit | 40,571 | 40,571 | identical |
| FM Tape | 39,686 | 39,686 | identical |
| PingPong | 35,742 | 35,742 | identical |
| FM Bass | 15,220 | 15,220 | identical |
| FM Shakr | 13,639 | 13,639 | identical |
| FM Phase | 11,273 | 11,273 | identical |
| FM Loop | 11,256 | 11,256 | identical |
| 2op | 6,423 | 6,423 | identical |

Macro Osc and Ring Mod have no devsim driver (as in kit 028b); their DSP
object code is unchanged from kit 028b.

## Not yet tested on hardware

The player hooks (FM Chord's page), the drum page press latch and the preset
sites were matched by bytes in the 1.2.1 OS but have not run on a device.

## Tests

sdk.py check; fixed-kit install tests with no layout, the kit 016 layout and
the kit 026 layout; devsim on every machine with a driver. Host checks only.

Credits: built on etcetc000's open-xy (MIT); see LICENSE.
